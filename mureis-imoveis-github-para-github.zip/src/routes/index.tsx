import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowRight, Check, MapPin } from "lucide-react";
import heroImage from "@/assets/hero-home.jpg";
import { Button } from "@/components/ui/button";
import { SearchForm } from "@/components/site/SearchForm";
import { SectionHeading } from "@/components/site/SectionHeading";
import { PropertyCard } from "@/components/site/PropertyCard";
import { regions } from "@/data/properties";
import { useSupabaseProperties, useSiteSettings, useVitorinoLaunch } from "@/hooks/use-supabase-content";
import { waMessages, whatsappLink } from "@/data/site";
import { brl } from "@/lib/format";
import { trackEvent } from "@/lib/tracking";

const title = "Mureis Imóveis | Curadoria imobiliária em São José dos Campos";
const description =
  "Imóveis selecionados, lançamentos e atendimento imobiliário estratégico em São José dos Campos e região.";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title },
      { name: "description", content: description },
      { property: "og:title", content: title },
      { property: "og:description", content: description },
      { property: "og:type", content: "website" },
      { property: "og:url", content: "/" },
    ],
    links: [{ rel: "canonical", href: "/" }],
  }),
  component: Index,
});

const featuredNeighborhoods = [
  "Urbanova",
  "Jardim Aquarius",
  "Jardim das Colinas",
  "Jardim Ismênia",
];

function neighborhoodSlug(name: string) {
  return name
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase()
    .replace(/\s+/g, "-");
}

function Index() {
  const properties = useSupabaseProperties();
  const siteSettings = useSiteSettings();
  const home = siteSettings.home;
  const cover = home?.heroImage || heroImage;
  const featured = properties.filter((property) => property.featured);
  const highlight = useVitorinoLaunch();
  const neighborhoodCards = featuredNeighborhoods
    .map((name) => regions.find((region) => region.name === name))
    .filter((region): region is (typeof regions)[number] => Boolean(region));

  return (
    <>
      <section className="relative overflow-hidden bg-primary text-primary-foreground">
        <div className="absolute inset-x-0 top-0 h-[255px] sm:h-[340px] lg:hidden" aria-hidden="true">
          <img
            src={cover}
            alt=""
            width={1920}
            height={1088}
            fetchPriority="high"
            className="h-full w-full object-cover object-center"
          />
          <div className="absolute inset-x-0 bottom-0 h-24 bg-gradient-to-t from-primary to-transparent" />
        </div>
        <div className="absolute inset-y-0 right-0 hidden w-[46%] lg:block">
          <img
            src={cover}
            alt="Imagem ilustrativa de uma residência contemporânea"
            width={1920}
            height={1088}
            fetchPriority="high"
            className="h-full w-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-primary via-primary/25 to-transparent" />
        </div>
        <div className="container-page relative z-10 pb-5 pt-[155px] sm:pb-10 sm:pt-[300px] lg:py-14">
          <div className="max-w-2xl">
            <h1 className="max-w-2xl font-display text-[clamp(1.9rem,7.6vw,2.35rem)] font-medium leading-[1.04] text-primary-foreground sm:text-5xl">
              {home?.heroTitle || "A experiência imobiliária que o seu patrimônio merece."}
            </h1>
            <p className="mt-2 max-w-2xl text-[0.94rem] leading-[1.4] text-primary-foreground/85 sm:mt-5 sm:text-lg sm:leading-7">
              {home?.heroSubtitle ||
                "Assessoria especializada para quem busca comprar, vender ou investir com total segurança e agilidade."}
            </p>
          </div>
          <div className="mt-4 lg:mt-10">
            <SearchForm />
          </div>
        </div>
      </section>

      {highlight && <section className="bg-surface py-6 sm:py-8 lg:py-10">
        <div className="container-page">
          <div className="grid overflow-hidden bg-primary text-primary-foreground shadow-[0_24px_70px_-42px_rgba(8,20,48,.75)] lg:min-h-[clamp(420px,52vh,520px)] lg:grid-cols-[1.32fr_0.68fr]">
            <div className="relative min-h-[clamp(260px,68vw,390px)] lg:min-h-full">
              <img
                src={highlight.image}
                alt={`${highlight.name} — ${highlight.neighborhood}`}
                loading="lazy"
                width={1400}
                height={900}
                className="absolute inset-0 h-full w-full object-cover object-center lg:object-[center_54%]"
              />
              <div className="absolute inset-0 bg-gradient-to-r from-transparent via-transparent to-primary/35" />
            </div>
            <div className="flex items-center p-6 sm:p-8 lg:p-9 xl:p-11">
              <div>
                <p className="text-xs font-semibold uppercase tracking-[0.2em] text-accent">
                  {home?.launchEyebrow || "Empreendimento em destaque"}
                </p>
                <h2 className="mt-3 font-display text-4xl font-medium leading-[.95] sm:text-5xl">
                  {highlight.name}
                </h2>
                <p className="mt-3 flex items-center gap-2 text-sm text-primary-foreground/60">
                  <MapPin className="h-4 w-4 text-accent" /> {highlight.neighborhood},{" "}
                  {highlight.city}
                </p>
                <div className="mt-5 grid gap-2 border-y border-primary-foreground/12 py-4 sm:grid-cols-2 lg:grid-cols-1">
                  {highlight.highlights.slice(0, 4).map((item) => (
                    <p
                      key={item}
                      className="flex items-center gap-3 text-sm text-primary-foreground/76"
                    >
                      <Check className="h-4 w-4 text-accent" /> {item}
                    </p>
                  ))}
                </div>
                <p className="mt-5 text-xs uppercase tracking-[0.16em] text-primary-foreground/48">
                  A partir de
                </p>
                <p className="mt-1 font-display text-3xl text-primary-foreground">
                  {brl(highlight.priceFrom)}
                </p>
                <Button
                  asChild
                  className="mt-5 h-12 rounded-none bg-accent px-7 text-accent-foreground hover:bg-accent/90"
                  onClick={() => trackEvent("launch_cta_click", { launch: highlight.slug })}
                >
                  <Link to="/lancamentos" hash={highlight.slug}>
                    {home?.launchButton || "Conhecer o Vitorino"} <ArrowRight className="ml-2 h-4 w-4" />
                  </Link>
                </Button>
              </div>
            </div>
          </div>
        </div>
      </section>}

      <section className="overflow-hidden py-10 sm:py-12 lg:py-14">
        <div className="container-page">
          <div className="flex flex-col justify-between gap-6 sm:flex-row sm:items-end">
            <SectionHeading
              eyebrow={home?.featuredEyebrow || "Imóveis em destaque"}
              title={home?.featuredTitle || "Imóveis selecionados para você"}
              subtitle={home?.featuredSubtitle || "Arraste para o lado e conheça as oportunidades em nosso portfólio."}
            />
            <Link
              to="/imoveis"
              className="inline-flex shrink-0 items-center gap-2 border-b border-primary pb-1 text-sm font-semibold text-primary"
            >
              {home?.featuredButton || "Ver todos os imóveis"} <ArrowRight className="h-4 w-4" />
            </Link>
          </div>
          <div className="-mx-6 mt-6 overflow-x-auto px-6 pb-5 [scrollbar-width:thin] [scrollbar-color:var(--primary)_var(--surface)] sm:-mx-8 sm:px-8 lg:mx-0 lg:px-0">
            <div className="flex w-max snap-x snap-mandatory gap-6">
              {featured.map((property) => (
                <div
                  key={property.id}
                  className="w-[82vw] max-w-[360px] shrink-0 snap-start sm:w-[340px] lg:w-[370px]"
                >
                  <PropertyCard property={property} />
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      <section className="border-y border-border bg-surface py-12 lg:py-16">
        <div className="container-page">
          <div className="flex flex-col justify-between gap-6 sm:flex-row sm:items-end">
            <SectionHeading
              eyebrow={home?.blogEyebrow || "Blog Mureis"}
              title={home?.blogTitle || "Conheça os bairros antes de escolher"}
              subtitle={home?.blogSubtitle || "Descubra o estilo de vida, a infraestrutura e os principais diferenciais de cada região."}
            />
            <Link
              to="/bairros"
              className="inline-flex shrink-0 items-center gap-2 border-b border-primary pb-1 text-sm font-semibold text-primary"
            >
              {home?.blogButton || "Ver todos os bairros"} <ArrowRight className="h-4 w-4" />
            </Link>
          </div>
          <div className="-mx-6 mt-10 overflow-x-auto px-6 pb-4 sm:-mx-8 sm:px-8 lg:mx-0 lg:px-0">
            <div className="flex w-max snap-x snap-mandatory gap-4 lg:grid lg:w-full lg:grid-cols-4">
              {neighborhoodCards.map((region) => (
                <Link
                  key={region.name}
                  to="/bairros"
                  hash={neighborhoodSlug(region.name)}
                  className="group relative aspect-[4/5] w-[72vw] max-w-[285px] shrink-0 snap-start overflow-hidden bg-primary lg:w-auto lg:max-w-none"
                >
                  <img
                    src={region.image}
                    alt={`Imóveis no ${region.name}`}
                    loading="lazy"
                    width={720}
                    height={900}
                    className="absolute inset-0 h-full w-full object-cover transition-transform duration-700 group-hover:scale-105"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-primary via-primary/5 to-transparent" />
                  <div className="absolute inset-x-0 bottom-0 p-5 sm:p-6">
                    <p className="text-[0.68rem] font-semibold uppercase tracking-[0.18em] text-accent">
                      Conheça
                    </p>
                    <h3 className="mt-2 font-display text-2xl font-medium text-primary-foreground">
                      {region.name}
                    </h3>
                    <span className="mt-3 inline-flex items-center gap-2 text-sm text-primary-foreground/75">
                      Ver guia do bairro{" "}
                      <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
                    </span>
                  </div>
                </Link>
              ))}
            </div>
          </div>
        </div>
      </section>

      <section className="py-9 sm:py-11 lg:py-14">
        <div className="container-page grid gap-7 lg:grid-cols-[0.72fr_1.28fr] lg:items-center lg:gap-14">
          <div className="relative mx-auto w-full max-w-[330px] sm:max-w-[390px] lg:max-w-none">
            <div className="absolute -bottom-3 -right-3 h-full w-full border border-accent/55" />
            <div className="relative aspect-[4/4.7] overflow-hidden bg-primary">
              <img
                src={home?.aboutImage || "/pedro-henrique-mureis.png"}
                alt={`${home?.aboutName || "Pedro Cardoso"}, corretor à frente da Mureis Imóveis`}
                loading="lazy"
                width={756}
                height={1344}
                className="h-full w-full object-cover object-top"
              />
              <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-primary/80 to-transparent p-5 pt-16 text-primary-foreground sm:p-6 sm:pt-20">
                <p className="font-display text-xl font-medium sm:text-2xl">{home?.aboutName || "Pedro Cardoso"}</p>
                <p className="mt-1 text-sm text-primary-foreground/70">{home?.aboutCreci || "CRECI 283.017"}</p>
              </div>
            </div>
          </div>
          <div>
            <p className="text-xs font-semibold uppercase tracking-[0.2em] text-accent-foreground">
              {home?.aboutEyebrow || "A visão por trás da Mureis"}
            </p>
            <h2 className="mt-4 max-w-3xl font-display text-3xl font-medium leading-[1.08] text-foreground sm:text-4xl lg:text-5xl">
              {home?.aboutTitle || "Experiência de mercado com a agilidade de uma imobiliária atual."}
            </h2>
            <p className="mt-4 max-w-3xl text-base leading-7 text-muted-foreground sm:text-lg sm:leading-8">
              {home?.aboutText || "Pedro Cardoso atua no mercado imobiliário desde 2017. A Mureis nasce dessa vivência prática, unindo conhecimento do mercado imobiliário, negociação próxima, tecnologia e marketing para entregar uma experiência mais clara e eficiente."}
            </p>
            <div className="mt-5 grid gap-4 border-t border-border pt-5 sm:grid-cols-3">
              {[
                ["Desde 2017", "conhecimento do mercado imobiliário"],
                ["SJC e região", "conhecimento de bairros e oportunidades"],
                ["Ponta a ponta", "compra, venda, lançamento e divulgação"],
              ].map(([value, label]) => (
                <div key={value}>
                  <p className="font-display text-2xl font-medium text-primary">{value}</p>
                  <p className="mt-1 text-sm leading-relaxed text-muted-foreground">{label}</p>
                </div>
              ))}
            </div>
            <Button asChild variant="outline" className="mt-6 h-12 rounded-none px-7">
              <Link to="/sobre">{home?.aboutButton || "Conhecer a Mureis"}</Link>
            </Button>
          </div>
        </div>
      </section>

      <section className="bg-primary py-9 text-primary-foreground sm:py-11 lg:py-12">
        <div className="container-page grid gap-6 lg:grid-cols-[minmax(0,1fr)_300px] lg:items-center lg:gap-10">
          <div>
            <p className="text-xs font-semibold uppercase tracking-[0.2em] text-accent">
              {home?.ownersEyebrow || "Proprietários"}
            </p>
            <h2 className="mt-4 max-w-3xl font-display text-3xl font-medium leading-tight sm:text-4xl lg:text-5xl">
              {home?.ownersTitle || "Seu imóvel merece estratégia, apresentação e o comprador certo."}
            </h2>
            <p className="mt-4 max-w-2xl leading-relaxed text-primary-foreground/68">
              {home?.ownersDescription || "Avaliação de mercado, produção do anúncio e divulgação direcionada para posicionar seu imóvel com clareza e valor."}
            </p>
          </div>
          <div className="w-full">
            <Button
              asChild
              className="h-12 w-full rounded-none bg-[#25D366] px-7 font-semibold text-white hover:bg-[#1fbd59] lg:h-14 lg:text-base"
            >
              <a href={whatsappLink(waMessages.evaluation)} target="_blank" rel="noreferrer">
                <span className="lg:hidden">WhatsApp</span>
                <span className="hidden lg:inline">{home?.ownersButton || "Anunciar meu imóvel pelo WhatsApp"}</span>
              </a>
            </Button>
          </div>
        </div>
      </section>
    </>
  );
}
