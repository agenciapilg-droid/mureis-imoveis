import { createFileRoute } from "@tanstack/react-router";
import { Check } from "lucide-react";

import { OwnerForm } from "@/components/site/OwnerForm";
import { Button } from "@/components/ui/button";

export const Route = createFileRoute("/anuncie")({
  head: () => ({
    meta: [
      { title: "Anuncie seu imóvel com a Mureis Imóveis" },
      {
        name: "description",
        content:
          "Conte com estratégia, apresentação profissional e acompanhamento próximo para vender ou alugar seu imóvel com a Mureis.",
      },
    ],
  }),
  component: AdvertisePage,
});

const steps = [
  ["01", "Conhecemos o imóvel", "Entendemos as características, o momento e o seu objetivo."],
  ["02", "Definimos o posicionamento", "Construímos uma estratégia coerente de apresentação e divulgação."],
  ["03", "Apresentamos ao mercado", "Conectamos o imóvel a compradores ou locatários com real potencial."],
  ["04", "Conduzimos até o fechamento", "Acompanhamos visitas, propostas e cada etapa da negociação."],
];

function AdvertisePage() {
  return (
    <main className="bg-background text-foreground">
      <section className="overflow-hidden bg-primary text-primary-foreground">
        <div className="mx-auto grid max-w-7xl items-center gap-8 px-5 py-8 sm:px-8 md:grid-cols-[1.05fr_.95fr] md:py-10 lg:gap-12 lg:px-12 lg:py-12">
          <div className="relative z-10 max-w-2xl">
            <p className="mb-4 text-xs font-bold uppercase tracking-[0.28em] text-accent">
              Anuncie com a Mureis
            </p>
            <h1 className="font-display text-4xl leading-[1.05] sm:text-5xl lg:text-6xl">
              Seu imóvel merece mais do que um anúncio.
            </h1>
            <p className="mt-5 max-w-xl text-base leading-7 text-primary-foreground/75 sm:text-lg sm:leading-8">
              Merece estratégia, apresentação e acompanhamento para chegar às pessoas certas e gerar uma negociação segura.
            </p>

            <div className="mt-7">
              <Button asChild size="lg" className="min-h-12 bg-accent px-7 text-primary hover:bg-accent/90">
                <a href="#cadastre-se">Quero anunciar meu imóvel</a>
              </Button>
            </div>
          </div>

          <div className="relative mx-auto w-full max-w-[520px] md:mx-0 md:ml-auto">
            <div className="absolute -inset-4 translate-x-5 translate-y-5 border border-accent/45" />
            <div className="relative aspect-[4/5] overflow-hidden bg-primary-foreground/5">
              <img
                src="/pedro-anuncie-mureis.png"
                alt="Pedro Henrique Cardoso, especialista da Mureis Imóveis"
                className="h-full w-full object-cover object-[center_28%] grayscale"
              />
              <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-primary via-primary/75 to-transparent px-6 pb-6 pt-20">
                <p className="font-display text-2xl">Pedro Henrique Cardoso</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="border-b border-border bg-card">
        <div className="mx-auto grid max-w-7xl gap-3 px-5 py-6 sm:grid-cols-3 sm:px-8 lg:px-12">
          {["Estratégia comercial", "Apresentação profissional", "Atendimento até o fechamento"].map((item) => (
            <div key={item} className="flex items-center gap-3 text-sm font-semibold">
              <span className="grid size-6 shrink-0 place-items-center rounded-full bg-accent/15 text-accent-foreground">
                <Check className="size-3.5" />
              </span>
              {item}
            </div>
          ))}
        </div>
      </section>

      <section className="bg-secondary/55">
        <div className="mx-auto max-w-7xl px-5 py-10 sm:px-8 md:py-14 lg:px-12">
          <div className="max-w-2xl">
            <p className="text-xs font-bold uppercase tracking-[0.24em] text-accent-foreground">Como funciona</p>
            <h2 className="mt-4 font-display text-3xl sm:text-4xl">Um processo claro do início ao fim.</h2>
          </div>
          <div className="mt-7 grid gap-px overflow-hidden border border-border bg-border md:grid-cols-4">
            {steps.map(([number, title, description]) => (
              <article key={number} className="bg-background p-5 lg:p-6">
                <span className="font-display text-3xl text-accent-foreground/55">{number}</span>
                <h3 className="mt-5 font-display text-xl">{title}</h3>
                <p className="mt-3 text-sm leading-6 text-muted-foreground">{description}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section id="cadastre-se" className="scroll-mt-24">
        <div className="mx-auto grid max-w-7xl gap-7 px-5 py-9 sm:px-8 md:py-12 lg:grid-cols-[.68fr_1.32fr] lg:gap-14 lg:px-12">
          <div className="max-w-xl lg:sticky lg:top-28 lg:self-start">
            <p className="text-xs font-bold uppercase tracking-[0.24em] text-accent-foreground">Fale sobre o seu imóvel</p>
            <h2 className="mt-4 font-display text-3xl leading-tight sm:text-4xl lg:text-5xl">
              Vamos construir a melhor estratégia para o seu imóvel.
            </h2>
          </div>

          <div className="border border-border bg-card p-5 shadow-[0_24px_70px_-50px_rgba(8,20,48,.45)] sm:p-8 lg:p-10">
            <OwnerForm />
          </div>
        </div>
      </section>
    </main>
  );
}
