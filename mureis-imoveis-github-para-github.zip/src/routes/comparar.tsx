import { createFileRoute, Link } from "@tanstack/react-router";
import { X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { getPropertiesByIds } from "@/data/properties";
import { useCompare } from "@/hooks/use-saved-properties";
import { brl } from "@/lib/format";

const title = "Comparar imóveis | Mureis Imóveis";
const description =
  "Compare até três imóveis lado a lado: preço, área, dormitórios, vagas, condomínio e IPTU.";

export const Route = createFileRoute("/comparar")({
  head: () => ({
    meta: [
      { title },
      { name: "description", content: description },
      { property: "og:title", content: title },
      { property: "og:description", content: description },
      { property: "og:url", content: "/comparar" },
      { name: "robots", content: "noindex" },
    ],
    links: [{ rel: "canonical", href: "/comparar" }],
  }),
  component: ComparePage,
});

function ComparePage() {
  const { ids, ready, remove, clear } = useCompare();
  const list = getPropertiesByIds(ids);

  const rows: { label: string; value: (i: number) => string }[] = [
    { label: "Preço", value: (i) => brl(list[i]!.price) },
    { label: "Bairro", value: (i) => `${list[i]!.neighborhood}, ${list[i]!.city}` },
    { label: "Área útil", value: (i) => `${list[i]!.area} m²` },
    { label: "Quartos", value: (i) => String(list[i]!.bedrooms) },
    { label: "Suítes", value: (i) => String(list[i]!.suites) },
    { label: "Banheiros", value: (i) => String(list[i]!.baths) },
    { label: "Vagas", value: (i) => String(list[i]!.parking) },
    { label: "Condomínio", value: (i) => (list[i]!.condoFee ? brl(list[i]!.condoFee) : "—") },
    { label: "IPTU", value: (i) => (list[i]!.iptu ? brl(list[i]!.iptu) : "—") },
    { label: "Características", value: (i) => list[i]!.features.slice(0, 4).join(", ") || "—" },
  ];

  return (
    <div className="container-page py-12">
      <h1 className="text-2xl font-semibold text-foreground sm:text-3xl">Comparar imóveis</h1>
      <p className="mt-2 text-sm text-muted-foreground">
        Você pode comparar até três imóveis por vez.
      </p>

      {!ready ? null : list.length === 0 ? (
        <div className="mt-10 rounded-sm border border-dashed border-border p-12 text-center">
          <p className="font-display text-lg font-semibold text-foreground">
            Nenhum imóvel no comparador
          </p>
          <p className="mt-2 text-sm text-muted-foreground">
            Use o ícone de comparação nos cards de imóvel.
          </p>
          <Button asChild className="mt-6 rounded-xs">
            <Link to="/imoveis">Ver imóveis</Link>
          </Button>
        </div>
      ) : (
        <>
          <div className="mt-6">
            <Button variant="outline" className="rounded-xs" onClick={clear}>
              Limpar comparação
            </Button>
          </div>
          <div className="mt-8 overflow-x-auto">
            <table className="w-full min-w-[640px] border-collapse text-sm">
              <thead>
                <tr>
                  <th className="w-36 border-b border-border p-3 text-left text-xs uppercase tracking-[0.1em] text-muted-foreground">
                    Item
                  </th>
                  {list.map((p) => (
                    <th key={p.id} className="border-b border-border p-3 text-left align-top">
                      <div className="flex items-start justify-between gap-2">
                        <Link
                          to="/imovel/$slug"
                          params={{ slug: p.slug }}
                          className="font-medium text-foreground hover:text-primary"
                        >
                          {p.title}
                        </Link>
                        <button
                          onClick={() => remove(p.id)}
                          aria-label="Remover da comparação"
                          className="text-muted-foreground hover:text-destructive"
                        >
                          <X className="h-4 w-4" />
                        </button>
                      </div>
                      <p className="mt-1 text-xs font-normal text-muted-foreground">{p.code}</p>
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {rows.map((row) => (
                  <tr key={row.label} className="odd:bg-surface">
                    <th
                      scope="row"
                      className="p-3 text-left text-xs font-medium uppercase tracking-[0.08em] text-muted-foreground"
                    >
                      {row.label}
                    </th>
                    {list.map((p, i) => (
                      <td key={p.id} className="p-3 text-foreground">
                        {row.value(i)}
                      </td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </>
      )}
    </div>
  );
}
