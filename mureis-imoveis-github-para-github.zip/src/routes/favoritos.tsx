import { createFileRoute, Link } from "@tanstack/react-router";
import { Button } from "@/components/ui/button";
import { PropertyCard } from "@/components/site/PropertyCard";
import { getPropertiesByIds } from "@/data/properties";
import { useFavorites } from "@/hooks/use-saved-properties";

const title = "Imóveis favoritos | Mureis Imóveis";
const description = "Sua lista de imóveis salvos em São José dos Campos e região.";

export const Route = createFileRoute("/favoritos")({
  head: () => ({
    meta: [
      { title },
      { name: "description", content: description },
      { property: "og:title", content: title },
      { property: "og:description", content: description },
      { property: "og:url", content: "/favoritos" },
      { name: "robots", content: "noindex" },
    ],
    links: [{ rel: "canonical", href: "/favoritos" }],
  }),
  component: FavoritesPage,
});

function FavoritesPage() {
  const { ids, ready, clear } = useFavorites();
  const list = getPropertiesByIds(ids);

  return (
    <div className="container-page py-12">
      <h1 className="text-2xl font-semibold text-foreground sm:text-3xl">Meus favoritos</h1>
      <p className="mt-2 text-sm text-muted-foreground">
        Os imóveis ficam salvos neste navegador enquanto você não cria uma conta.
      </p>

      {!ready ? null : list.length === 0 ? (
        <div className="mt-10 rounded-sm border border-dashed border-border p-12 text-center">
          <p className="font-display text-lg font-semibold text-foreground">
            Nenhum imóvel salvo ainda
          </p>
          <p className="mx-auto mt-2 max-w-md text-sm text-muted-foreground">
            Toque no coração de um imóvel para guardá-lo aqui e comparar com calma depois.
          </p>
          <Button asChild className="mt-6 rounded-xs">
            <Link to="/imoveis">Ver imóveis</Link>
          </Button>
        </div>
      ) : (
        <>
          <div className="mt-6 flex gap-3">
            <Button asChild variant="outline" className="rounded-xs">
              <Link to="/comparar">Comparar imóveis</Link>
            </Button>
            <Button variant="outline" className="rounded-xs" onClick={clear}>
              Limpar lista
            </Button>
          </div>
          <div className="mt-8 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {list.map((p) => (
              <PropertyCard key={p.id} property={p} />
            ))}
          </div>
        </>
      )}
    </div>
  );
}
