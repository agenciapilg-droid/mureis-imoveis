import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import {
  Bath,
  BedDouble,
  Building2,
  Car,
  ChevronLeft,
  ChevronRight,
  Heart,
  Maximize,
  Receipt,
  Ruler,
  ShowerHead,
  X,
} from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { PropertyCard } from "@/components/site/PropertyCard";
import { getProperty, similarProperties, type Property } from "@/data/properties";
import { whatsappLink } from "@/data/site";
import { brl } from "@/lib/format";
import { useFavorites } from "@/hooks/use-saved-properties";
import { applyVitorinoProperty, isVitorino, mapProperty, type VitorinoContent } from "@/hooks/use-supabase-content";
import { supabase } from "@/lib/supabase";

export const Route = createFileRoute("/imovel/$slug")({
  loader: async ({ params }) => {
    const { data } = await supabase
      .from("published_properties")
      .select("*")
      .eq("organization_slug", "mureis-imoveis")
      .eq("slug", params.slug)
      .maybeSingle();
    let property = data ? mapProperty(data) : getProperty(params.slug);
    if (property && isVitorino(property)) {
      const { data: settings } = await supabase.from("site_settings").select("home")
        .eq("organization_id", "11111111-1111-4111-8111-111111111111").maybeSingle();
      const vitorino = (settings?.home as { vitorino?: VitorinoContent } | null)?.vitorino;
      if (vitorino?.visible === false) throw notFound();
      property = applyVitorinoProperty(property, vitorino);
    }
    if (!property) throw notFound();
    return { property };
  },
  head: ({ loaderData, params }) => {
    if (!loaderData) {
      return { meta: [{ title: "Imóvel não encontrado" }, { name: "robots", content: "noindex" }] };
    }
    const p = loaderData.property;
    const title = `${p.title} — ${p.neighborhood}, ${p.city} | Mureis Imóveis`;
    const description = `${p.type} com ${p.area} m² em ${p.neighborhood}, ${p.city}. ${brl(p.price)}. Código ${p.code}.`;
    return {
      meta: [
        { title },
        { name: "description", content: description },
        { property: "og:title", content: title },
        { property: "og:description", content: description },
        { property: "og:type", content: "product" },
        { property: "og:url", content: `/imovel/${params.slug}` },
      ],
      links: [{ rel: "canonical", href: `/imovel/${params.slug}` }],
      scripts: [
        {
          type: "application/ld+json",
          children: JSON.stringify({
            "@context": "https://schema.org",
            "@type": "Residence",
            name: p.title,
            address: {
              "@type": "PostalAddress",
              addressLocality: p.city,
              addressRegion: "SP",
              addressCountry: "BR",
            },
            floorSize: { "@type": "QuantitativeValue", value: p.area, unitCode: "MTK" },
            numberOfRooms: p.bedrooms,
          }),
        },
      ],
    };
  },
  notFoundComponent: () => (
    <div className="container-page py-24 text-center">
      <h1 className="text-2xl font-semibold text-foreground">Imóvel não encontrado</h1>
      <p className="mt-3 text-sm text-muted-foreground">
        Ele pode ter sido vendido ou retirado do site.
      </p>
      <Button asChild className="mt-6 rounded-xs">
        <Link to="/imoveis">Ver imóveis disponíveis</Link>
      </Button>
    </div>
  ),
  component: PropertyPage,
});

function PropertyPage() {
  const { property } = Route.useLoaderData() as { property: Property };
  const favorites = useFavorites();
  const [active, setActive] = useState(0);
  const [open, setOpen] = useState(false);

  const waMessage = `Olá, gostaria de receber mais informações sobre o imóvel código ${property.code}, ${property.title}, localizado no ${property.neighborhood}.`;

  const specs = [
    { icon: Maximize, label: "Área útil", value: `${property.area} m²` },
    {
      icon: Ruler,
      label: "Área do terreno",
      value: property.landArea ? `${property.landArea} m²` : "—",
    },
    { icon: BedDouble, label: "Quartos", value: String(property.bedrooms) },
    { icon: Bath, label: "Suítes", value: String(property.suites) },
    { icon: ShowerHead, label: "Banheiros", value: String(property.baths) },
    { icon: Car, label: "Vagas", value: String(property.parking) },
    {
      icon: Building2,
      label: "Condomínio",
      value: property.condoFee ? brl(property.condoFee) : "—",
    },
    { icon: Receipt, label: "IPTU", value: property.iptu ? `${brl(property.iptu)}/mês` : "—" },
  ];

  return (
    <div className="pb-24 lg:pb-0">
      <div className="container-page pt-8">
        <nav aria-label="Você está aqui" className="text-xs text-muted-foreground">
          <Link to="/" className="hover:text-primary">
            Início
          </Link>
          <span className="px-1.5">/</span>
          <Link to="/imoveis" className="hover:text-primary">
            Imóveis
          </Link>
          <span className="px-1.5">/</span>
          <Link
            to="/imoveis"
            search={{ neighborhood: property.neighborhood }}
            className="hover:text-primary"
          >
            {property.neighborhood}
          </Link>
          <span className="px-1.5">/</span>
          <span className="text-foreground">{property.code}</span>
        </nav>
      </div>

      <section className="container-page mt-6">
        <div className="grid gap-2 lg:grid-cols-[1.65fr_0.7fr]">
          <button
            type="button"
            onClick={() => {
              setActive(0);
              setOpen(true);
            }}
            className="relative aspect-[4/3] overflow-hidden bg-muted sm:aspect-[16/10] lg:aspect-auto lg:min-h-[clamp(500px,62vh,650px)]"
          >
            <img
              src={property.images[0]}
              alt={property.title}
              className="h-full w-full object-cover"
              width={1200}
              height={800}
            />
          </button>
          <div className="grid grid-cols-2 gap-2 lg:grid-cols-1 lg:grid-rows-2">
            {property.images.slice(1, 5).map((img, i) => (
              <button
                key={img + i}
                type="button"
                onClick={() => {
                  setActive(i + 1);
                  setOpen(true);
                }}
                className="relative aspect-[16/10] overflow-hidden bg-muted lg:aspect-auto"
              >
                <img
                  src={img}
                  alt={`${property.title} — foto ${i + 2}`}
                  loading="lazy"
                  className="h-full w-full object-cover"
                />
              </button>
            ))}
          </div>
        </div>
        <div className="mt-3 flex flex-wrap gap-2">
          <Button variant="outline" className="rounded-xs" onClick={() => setOpen(true)}>
            Ver todas as fotos ({property.images.length})
          </Button>
          <Button
            variant="outline"
            className="rounded-xs"
            onClick={() => {
              const added = favorites.toggle(property.id);
              toast.success(added ? "Imóvel salvo nos favoritos" : "Removido dos favoritos");
            }}
          >
            <Heart className={`mr-2 h-4 w-4 ${favorites.has(property.id) ? "fill-current" : ""}`} />
            {favorites.has(property.id) ? "Salvo" : "Favoritar"}
          </Button>
        </div>
      </section>

      <section className="container-page mt-10 grid gap-12 lg:grid-cols-[1fr_360px]">
        <div>
          <p className="eyebrow">
            {property.type} · Código {property.code}
          </p>
          <h1 className="mt-4 max-w-4xl font-display text-4xl font-medium leading-[1.05] text-foreground sm:text-5xl">
            {property.title}
          </h1>
          <p className="mt-2 text-sm text-muted-foreground">
            {property.condo ? `${property.condo} — ` : ""}
            {property.neighborhood}, {property.city}
          </p>
          <p className="mt-7 text-3xl font-semibold tracking-[-0.04em] text-primary">
            {brl(property.price)}
            {property.purpose === "aluguel" && (
              <span className="ml-1 text-base font-medium text-muted-foreground">/mês</span>
            )}
          </p>

          <dl className="mt-10 grid grid-cols-2 gap-px overflow-hidden border border-border bg-border sm:grid-cols-4">
            {specs.map((s) => (
              <div key={s.label} className="bg-card p-4">
                <s.icon className="h-4 w-4 text-muted-foreground" />
                <dt className="mt-2 text-xs text-muted-foreground">{s.label}</dt>
                <dd className="text-sm font-semibold text-foreground">{s.value}</dd>
              </div>
            ))}
          </dl>

          <div className="mt-10">
            <h2 className="text-lg font-semibold text-foreground">Sobre o imóvel</h2>
            <p className="mt-3 leading-relaxed text-muted-foreground">{property.description}</p>
          </div>

          {property.features.length > 0 && (
            <div className="mt-10">
              <h2 className="text-lg font-semibold text-foreground">Características</h2>
              <ul className="mt-4 grid gap-2 sm:grid-cols-2">
                {property.features.map((f) => (
                  <li key={f} className="flex items-center gap-2 text-sm text-muted-foreground">
                    <span className="h-1.5 w-1.5 rounded-full bg-accent" /> {f}
                  </li>
                ))}
              </ul>
            </div>
          )}

          {property.condoFeatures.length > 0 && (
            <div className="mt-10">
              <h2 className="text-lg font-semibold text-foreground">Itens do condomínio</h2>
              <ul className="mt-4 grid gap-2 sm:grid-cols-2">
                {property.condoFeatures.map((f) => (
                  <li key={f} className="flex items-center gap-2 text-sm text-muted-foreground">
                    <span className="h-1.5 w-1.5 rounded-full bg-accent" /> {f}
                  </li>
                ))}
              </ul>
            </div>
          )}

          <div className="mt-10">
            <h2 className="text-lg font-semibold text-foreground">Localização aproximada</h2>
            <div className="mt-4 flex aspect-[16/7] items-center justify-center rounded-sm border border-border bg-surface text-center">
              <div>
                <p className="text-sm font-medium text-foreground">
                  {property.neighborhood}, {property.city}
                </p>
                <p className="mt-1 text-xs text-muted-foreground">
                  O endereço exato é informado no atendimento, por segurança do proprietário.
                </p>
              </div>
            </div>
          </div>
        </div>

        <aside className="lg:sticky lg:top-24 lg:self-start">
          <div className="bg-navy-deep p-7 text-primary-foreground shadow-[0_24px_70px_-38px_rgba(8,20,48,0.7)]">
            <p className="text-xs font-semibold uppercase tracking-[0.18em] text-accent">
              Atendimento Mureis
            </p>
            <h2 className="mt-3 font-display text-3xl font-medium">Quer conhecer este imóvel?</h2>
            <p className="mt-3 text-sm leading-relaxed text-primary-foreground/62">
              Receba os detalhes, confirme a disponibilidade e agende uma visita com atendimento
              especializado.
            </p>
            <p className="mt-6 rounded-sm border border-primary-foreground/20 p-4 text-sm leading-relaxed text-primary-foreground/80">
              Valores, condições e disponibilidade podem mudar sem aviso prévio. Confirme as
              informações antes de tomar qualquer decisão.
            </p>

            <Button
              asChild
              className="mt-4 h-12 w-full rounded-none bg-[#25D366] font-semibold text-white hover:bg-[#1fbd59]"
            >
              <a href={whatsappLink(waMessage)} target="_blank" rel="noreferrer">
                Quero saber mais
              </a>
            </Button>
          </div>
        </aside>
      </section>

      <section className="container-page mt-16 pb-16">
        <h2 className="text-xl font-semibold text-foreground">Imóveis semelhantes</h2>
        <div className="mt-6 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {similarProperties(property).map((p) => (
            <PropertyCard key={p.id} property={p} />
          ))}
        </div>
      </section>

      <div className="fixed inset-x-0 bottom-0 z-40 border-t border-border bg-background p-3 lg:hidden">
        <Button asChild className="h-12 w-full rounded-xs bg-[#25D366] font-semibold text-white hover:bg-[#1fbd59]">
          <a href={whatsappLink(waMessage)} target="_blank" rel="noreferrer">Quero saber mais</a>
        </Button>
      </div>

      {open && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-navy-deep/95 p-4"
          role="dialog"
          aria-modal="true"
        >
          <button
            onClick={() => setOpen(false)}
            aria-label="Fechar galeria"
            className="absolute right-5 top-5 text-primary-foreground/80 hover:text-primary-foreground"
          >
            <X className="h-6 w-6" />
          </button>
          <button
            onClick={() =>
              setActive((i) => (i - 1 + property.images.length) % property.images.length)
            }
            aria-label="Foto anterior"
            className="absolute left-4 text-primary-foreground/80 hover:text-primary-foreground"
          >
            <ChevronLeft className="h-8 w-8" />
          </button>
          <img
            src={property.images[active]}
            alt={`${property.title} — foto ${active + 1}`}
            className="max-h-[80vh] max-w-full rounded-sm object-contain"
          />
          <button
            onClick={() => setActive((i) => (i + 1) % property.images.length)}
            aria-label="Próxima foto"
            className="absolute right-4 text-primary-foreground/80 hover:text-primary-foreground"
          >
            <ChevronRight className="h-8 w-8" />
          </button>
          <p className="absolute bottom-6 text-xs text-primary-foreground/70">
            {active + 1} de {property.images.length}
          </p>
        </div>
      )}
    </div>
  );
}
