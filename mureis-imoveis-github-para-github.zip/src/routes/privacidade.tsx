import { createFileRoute } from "@tanstack/react-router";

const title = "Política de privacidade | Mureis Imóveis";
const description = "Como a Mureis Imóveis coleta, usa e protege os dados enviados pelo site.";

export const Route = createFileRoute("/privacidade")({
  head: () => ({
    meta: [
      { title },
      { name: "description", content: description },
      { property: "og:title", content: title },
      { property: "og:description", content: description },
      { property: "og:url", content: "/privacidade" },
    ],
    links: [{ rel: "canonical", href: "/privacidade" }],
  }),
  component: () => (
    <div className="container-page max-w-3xl py-12">
      <h1 className="text-2xl font-semibold text-foreground">Política de privacidade</h1>
      <p className="mt-6 leading-relaxed text-muted-foreground">
        Os dados informados nos formulários deste site são utilizados exclusivamente para o
        atendimento imobiliário solicitado: retorno de contato, envio de opções de imóveis e
        agendamento de visitas.
      </p>
      <p className="mt-4 leading-relaxed text-muted-foreground">
        Não comercializamos dados pessoais. Favoritos e comparações ficam salvos apenas no seu
        navegador. Para solicitar a exclusão dos seus dados, entre em contato pelos canais
        disponíveis neste site.
      </p>
    </div>
  ),
});
