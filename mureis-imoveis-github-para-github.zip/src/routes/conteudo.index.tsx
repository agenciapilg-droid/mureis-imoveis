import { createFileRoute, Link } from "@tanstack/react-router";
import { SectionHeading } from "@/components/site/SectionHeading";
import { articles } from "@/data/properties";

const title = "Conteúdo imobiliário em São José dos Campos | Mureis Imóveis";
const description =
  "Guias sobre bairros, financiamento imobiliário e o que analisar antes de comprar um imóvel em São José dos Campos.";

export const Route = createFileRoute("/conteudo/")({
  head: () => ({
    meta: [
      { title },
      { name: "description", content: description },
      { property: "og:title", content: title },
      { property: "og:description", content: description },
      { property: "og:type", content: "website" },
      { property: "og:url", content: "/conteudo" },
    ],
    links: [{ rel: "canonical", href: "/conteudo" }],
  }),
  component: () => (
    <div className="container-page section-y">
      <SectionHeading
        eyebrow="Conteúdo"
        title="Conteúdo imobiliário"
        subtitle="Informação prática para decidir com mais segurança em São José dos Campos."
      />
      <div className="mt-10 grid gap-6 md:grid-cols-3">
        {articles.map((a) => (
          <article
            key={a.slug}
            className="flex flex-col overflow-hidden rounded-sm border border-border bg-card"
          >
            <div className="aspect-[16/9] overflow-hidden bg-muted">
              <img
                src={a.image}
                alt={a.title}
                loading="lazy"
                width={800}
                height={450}
                className="h-full w-full object-cover"
              />
            </div>
            <div className="flex flex-1 flex-col p-6">
              <p className="eyebrow">{a.category}</p>
              <h2 className="mt-3 text-lg font-semibold leading-snug text-foreground">
                <Link to="/conteudo/$slug" params={{ slug: a.slug }} className="hover:text-primary">
                  {a.title}
                </Link>
              </h2>
              <p className="mt-3 flex-1 text-sm leading-relaxed text-muted-foreground">
                {a.excerpt}
              </p>
              <p className="mt-4 text-xs text-muted-foreground">{a.readingTime}</p>
            </div>
          </article>
        ))}
      </div>
    </div>
  ),
});
