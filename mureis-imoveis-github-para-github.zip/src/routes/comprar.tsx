import { createFileRoute, redirect } from "@tanstack/react-router";

export const Route = createFileRoute("/comprar")({
  beforeLoad: () => {
    throw redirect({ to: "/imoveis", search: { purpose: "venda" } });
  },
});
