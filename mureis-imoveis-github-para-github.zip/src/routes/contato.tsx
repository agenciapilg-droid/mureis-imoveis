import { createFileRoute } from "@tanstack/react-router";
import { MapPin, MessageCircle, Phone } from "lucide-react";
import { SectionHeading } from "@/components/site/SectionHeading";
import { OwnerForm } from "@/components/site/OwnerForm";
import { site, whatsappLink } from "@/data/site";

const title = "Contato | Mureis Imóveis São José dos Campos";
const description =
  "Fale com a Mureis Imóveis sobre compra, venda, locação e investimentos imobiliários em São José dos Campos.";

export const Route = createFileRoute("/contato")({
  head: () => ({
    meta: [
      { title },
      { name: "description", content: description },
      { property: "og:title", content: title },
      { property: "og:description", content: description },
      { property: "og:url", content: "/contato" },
    ],
    links: [{ rel: "canonical", href: "/contato" }],
  }),
  component: () => (
    <div className="container-page grid gap-12 py-12 lg:grid-cols-[1fr_1.1fr]">
      <div>
        <SectionHeading
          eyebrow="Contato"
          title="Vamos conversar sobre o seu próximo imóvel"
          subtitle="Conte o que procura ou apresente o seu imóvel. Nossa equipe retornará com uma orientação objetiva para o seu momento."
        />
        <ul className="mt-8 space-y-4 text-sm">
          {site.whatsapp && (
            <li>
              <a
                className="inline-flex items-center gap-2.5 text-foreground hover:text-primary"
                href={whatsappLink("Olá, vim pelo site da Mureis Imóveis.")}
                target="_blank"
                rel="noreferrer"
              >
                <MessageCircle className="h-4 w-4 text-muted-foreground" /> WhatsApp
              </a>
            </li>
          )}
          {site.phone && (
            <li>
              <a
                className="inline-flex items-center gap-2.5 text-foreground hover:text-primary"
                href={`tel:${site.phoneRaw}`}
              >
                <Phone className="h-4 w-4 text-muted-foreground" /> {site.phone}
              </a>
            </li>
          )}
          <li className="flex items-start gap-2.5 text-muted-foreground">
            <MapPin className="mt-0.5 h-4 w-4" /> {site.address}
          </li>
        </ul>
        <p className="mt-8 text-xs text-muted-foreground">{site.creci}</p>
      </div>
      <div className="h-fit rounded-sm border border-border bg-card p-6 sm:p-8">
        <OwnerForm />
      </div>
    </div>
  ),
});
