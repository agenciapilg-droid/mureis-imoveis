import { createFileRoute } from "@tanstack/react-router";

const title = "Termos de uso | Mureis Imóveis";
const description =
  "Condições de uso do site da Mureis Imóveis e das informações publicadas sobre imóveis.";

export const Route = createFileRoute("/termos")({
  head: () => ({
    meta: [
      { title },
      { name: "description", content: description },
      { property: "og:title", content: title },
      { property: "og:description", content: description },
      { property: "og:url", content: "/termos" },
    ],
    links: [{ rel: "canonical", href: "/termos" }],
  }),
  component: () => (
    <div className="container-page max-w-3xl py-12">
      <h1 className="text-2xl font-semibold text-foreground">Termos de uso</h1>
      <p className="mt-6 leading-relaxed text-muted-foreground">
        As informações de metragem, valores, condomínio e IPTU são fornecidas pelos proprietários e
        podem sofrer alteração sem aviso prévio. Confirme os dados com um corretor antes de qualquer
        proposta.
      </p>
      <p className="mt-4 leading-relaxed text-muted-foreground">
        Imagens e textos deste site são de uso exclusivo da Mureis Imóveis e não podem ser
        reproduzidos sem autorização.
      </p>
    </div>
  ),
});
