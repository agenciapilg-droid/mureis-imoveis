import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowRight, Building2, KeyRound, LineChart, ShieldCheck } from "lucide-react";
import { Button } from "@/components/ui/button";
import { site, waMessages, whatsappLink } from "@/data/site";

const title = "Sobre a Mureis Imóveis | São José dos Campos";
const description =
  "Conheça a história da Mureis Imóveis: experiência prática no mercado desde 2017, estratégia e atendimento próximo em São José dos Campos.";

const principles = [
  {
    number: "01",
    title: "O imóvel é patrimônio",
    text: "Cada decisão envolve história, planejamento e dinheiro. Por isso, tratamos toda negociação com responsabilidade e clareza.",
  },
  {
    number: "02",
    title: "Estratégia antes da exposição",
    text: "Não se trata apenas de publicar. Posicionamento, apresentação e público certo mudam a percepção e o resultado de um imóvel.",
  },
  {
    number: "03",
    title: "Proximidade em cada etapa",
    text: "Acompanhamos a conversa, as visitas e a negociação de perto — sem transformar uma decisão importante em atendimento automático.",
  },
];

const expertise = [
  { icon: Building2, title: "Leitura de mercado", text: "Análise do imóvel, do momento e da concorrência antes de definir o posicionamento." },
  { icon: LineChart, title: "Estratégia comercial", text: "Apresentação, divulgação e negociação pensadas para proteger valor e acelerar decisões." },
  { icon: KeyRound, title: "Condução próxima", text: "Um atendimento presente, da primeira conversa à entrega das chaves." },
  { icon: ShieldCheck, title: "Decisões seguras", text: "Clareza documental, comunicação transparente e cuidado em cada etapa." },
];

export const Route = createFileRoute("/sobre")({
  head: () => ({
    meta: [
      { title },
      { name: "description", content: description },
      { property: "og:title", content: title },
      { property: "og:description", content: description },
      { property: "og:type", content: "website" },
      { property: "og:url", content: "/sobre" },
    ],
    links: [{ rel: "canonical", href: "/sobre" }],
    scripts: [
      {
        type: "application/ld+json",
        children: JSON.stringify({
          "@context": "https://schema.org",
          "@type": "RealEstateAgent",
          name: site.name,
          description,
          address: {
            "@type": "PostalAddress",
            addressLocality: "São José dos Campos",
            addressRegion: "SP",
            addressCountry: "BR",
          },
          areaServed: "São José dos Campos e região",
          url: "/",
        }),
      },
    ],
  }),
  component: Sobre,
});

function Sobre() {
  return (
    <main className="bg-background text-foreground">
      <section className="relative overflow-hidden border-b border-primary-foreground/10 bg-primary text-primary-foreground">
        <div className="absolute -right-28 -top-28 size-[420px] rounded-full border border-accent/20" />
        <div className="absolute -right-10 top-12 size-[260px] rounded-full border border-accent/10" />
        <div className="mx-auto grid max-w-7xl items-center gap-8 px-5 py-10 sm:px-8 md:grid-cols-[.64fr_1.36fr] md:py-14 lg:gap-16 lg:px-12 lg:py-16">
          <div className="relative flex min-h-52 items-center justify-center border border-primary-foreground/15 bg-primary-foreground/[.035] p-7 backdrop-blur-sm sm:min-h-60 sm:p-10">
            <span className="absolute left-0 top-0 h-px w-16 bg-accent" />
            <img src="/mureis-logo-oficial.png" alt="Mureis Imóveis" className="h-auto w-full max-w-[330px] object-contain" />
          </div>
          <div className="max-w-3xl">
            <p className="text-xs font-bold uppercase tracking-[0.28em] text-accent">Sobre a Mureis</p>
            <h1 className="mt-4 font-display text-4xl leading-[1.08] sm:text-5xl lg:text-6xl">
              Uma imobiliária construída dentro do mercado.
            </h1>
            <p className="mt-5 max-w-2xl text-base leading-7 text-primary-foreground/75 sm:text-lg sm:leading-8">
              Conhecimento de mercado, estratégia comercial e atendimento pessoal para transformar decisões importantes em negociações mais claras e seguras.
            </p>
          </div>
        </div>
      </section>

      <section className="border-b border-border bg-background">
        <div className="mx-auto grid max-w-7xl grid-cols-2 gap-px bg-border px-5 sm:px-8 md:grid-cols-4 lg:px-12">
          {expertise.map(({ icon: Icon, title, text }) => (
            <article key={title} className="bg-background px-4 py-7 sm:px-6 sm:py-8">
              <Icon className="h-5 w-5 text-accent-foreground" />
              <h2 className="mt-4 font-display text-xl leading-tight">{title}</h2>
              <p className="mt-2 text-sm leading-6 text-muted-foreground">{text}</p>
            </article>
          ))}
        </div>
      </section>

      <section className="mx-auto grid max-w-7xl gap-9 px-5 py-11 sm:px-8 md:grid-cols-[.72fr_1.28fr] md:items-center md:py-16 lg:gap-16 lg:px-12">
        <div className="relative mx-auto w-full max-w-[390px]">
          <div className="absolute -bottom-4 -right-4 h-full w-full border border-accent/60" aria-hidden="true" />
          <div className="relative aspect-[4/5] overflow-hidden bg-muted">
            <img src="/pedro-henrique-mureis.png" alt="Pedro Henrique Cardoso, fundador da Mureis Imóveis" className="h-full w-full object-cover object-[center_25%]" />
          </div>
        </div>
        <div className="max-w-3xl">
          <p className="text-xs font-bold uppercase tracking-[0.24em] text-accent-foreground">A origem</p>
          <h2 className="mt-4 font-display text-3xl leading-tight sm:text-4xl lg:text-5xl">
            Experiência de mercado transformada em uma imobiliária atual.
          </h2>
          <div className="mt-6 space-y-4 text-base leading-7 text-muted-foreground">
            <p>
              Pedro Henrique Cardoso atua no mercado imobiliário desde 2017. Ao longo dessa trajetória, esteve próximo de diferentes lados do setor: atendimento ao cliente, vendas, lançamentos, rotina de construtora e divulgação de imóveis.
            </p>
            <p>
              A Mureis foi criada a partir dessa vivência. Uma imobiliária com conhecimento prático, comunicação contemporânea e acompanhamento pessoal para quem deseja comprar, vender, alugar ou investir em São José dos Campos e região.
            </p>
          </div>
          <div className="mt-7 grid gap-4 border-t border-border pt-6 sm:grid-cols-3">
            <span className="font-display text-3xl text-primary">Desde 2017</span>
            <span className="text-sm leading-5 text-muted-foreground">conhecimento construído dentro do mercado imobiliário</span>
            <span className="text-sm leading-5 text-muted-foreground">atuação em São José dos Campos e região</span>
          </div>
        </div>
      </section>

      <section className="bg-secondary/55">
        <div className="mx-auto max-w-7xl px-5 py-12 sm:px-8 md:py-16 lg:px-12">
          <div className="max-w-2xl">
            <p className="text-xs font-bold uppercase tracking-[0.24em] text-accent-foreground">O jeito Mureis</p>
            <h2 className="mt-4 font-display text-3xl leading-tight sm:text-4xl">O que orienta o nosso trabalho.</h2>
          </div>
          <div className="mt-8 grid gap-px overflow-hidden border border-border bg-border md:grid-cols-3">
            {principles.map((principle) => (
              <article key={principle.number} className="bg-background p-6 lg:p-8">
                <span className="font-display text-3xl text-accent-foreground/55">{principle.number}</span>
                <h3 className="mt-6 font-display text-2xl">{principle.title}</h3>
                <p className="mt-3 leading-7 text-muted-foreground">{principle.text}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-5 py-12 sm:px-8 md:py-16 lg:px-12">
        <div className="grid items-center gap-7 border border-border bg-primary px-6 py-8 text-primary-foreground sm:px-9 lg:grid-cols-[1fr_auto] lg:px-12">
          <div>
            <p className="text-xs font-bold uppercase tracking-[0.24em] text-accent">Seu próximo passo</p>
            <h2 className="mt-3 max-w-2xl font-display text-3xl leading-tight sm:text-4xl">Vamos conversar sobre o seu imóvel?</h2>
          </div>
          <div className="flex flex-col gap-3 sm:flex-row">
            <Button asChild size="lg" className="min-h-12 bg-accent px-7 text-primary hover:bg-accent/90">
              <a href={whatsappLink(waMessages.general)} target="_blank" rel="noreferrer">
                Falar com a Mureis
                <ArrowRight className="ml-2 size-4" />
              </a>
            </Button>
            <Button asChild size="lg" variant="outline" className="min-h-12 border-primary-foreground/30 bg-transparent px-7 text-primary-foreground hover:bg-primary-foreground/10 hover:text-primary-foreground">
              <Link to="/imoveis">Ver imóveis</Link>
            </Button>
          </div>
        </div>
      </section>
    </main>
  );
}
