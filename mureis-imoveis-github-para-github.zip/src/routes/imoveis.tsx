import { createFileRoute, Link } from "@tanstack/react-router";
import { Filter, Map as MapIcon, LayoutGrid, X } from "lucide-react";
import { useEffect, useMemo, useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { PropertyCard, PropertyCardSkeleton } from "@/components/site/PropertyCard";
import { cities, condos, neighborhoods, propertyTypes } from "@/data/properties";
import { useSupabaseProperties } from "@/hooks/use-supabase-content";
import {
  applyFilters,
  countActive,
  emptyFilters,
  filtersFromSearch,
  sortProperties,
  type Filters,
  type SortKey,
} from "@/lib/filters";

const title = "Imóveis à venda e para alugar em São José dos Campos | Mureis Imóveis";
const description =
  "Busque casas, apartamentos, coberturas e terrenos em São José dos Campos por bairro, condomínio, faixa de preço, quartos e área.";

export const Route = createFileRoute("/imoveis")({
  validateSearch: (search: Record<string, unknown>) => search as Record<string, string>,
  head: () => ({
    meta: [
      { title },
      { name: "description", content: description },
      { property: "og:title", content: title },
      { property: "og:description", content: description },
      { property: "og:url", content: "/imoveis" },
    ],
    links: [{ rel: "canonical", href: "/imoveis" }],
  }),
  component: ListingPage,
});

const selectClass =
  "h-10 w-full rounded-xs border border-input bg-background px-3 text-sm outline-none focus-visible:border-primary focus-visible:ring-2 focus-visible:ring-primary/15";

const PAGE_SIZE = 6;

function ListingPage() {
  const properties = useSupabaseProperties();
  const search = Route.useSearch();
  const [filters, setFilters] = useState<Filters>(() => filtersFromSearch(search));
  const [sort, setSort] = useState<SortKey>("recentes");
  const [view, setView] = useState<"grade" | "mapa">("grade");
  const [visible, setVisible] = useState(PAGE_SIZE);
  const [drawer, setDrawer] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    setFilters(filtersFromSearch(search));
  }, [search]);

  useEffect(() => {
    setLoading(true);
    const t = setTimeout(() => setLoading(false), 300);
    return () => clearTimeout(t);
  }, [filters, sort]);

  const results = useMemo(
    () => sortProperties(applyFilters(properties, filters), sort),
    [filters, sort],
  );
  const set = <K extends keyof Filters>(key: K, value: Filters[K]) => {
    setVisible(PAGE_SIZE);
    setFilters((f) => ({ ...f, [key]: value }));
  };

  const panel = (
    <div className="space-y-6">
      <div className="space-y-2">
        <Label className="text-xs uppercase tracking-[0.1em] text-muted-foreground">
          Finalidade
        </Label>
        <div className="grid grid-cols-3 gap-1 rounded-xs border border-border p-1">
          {[
            { v: "", l: "Todos" },
            { v: "venda", l: "Comprar" },
            { v: "aluguel", l: "Alugar" },
          ].map((o) => (
            <button
              key={o.l}
              type="button"
              onClick={() => set("purpose", o.v as Filters["purpose"])}
              className={`rounded-xs py-1.5 text-xs font-medium transition-colors ${
                filters.purpose === o.v
                  ? "bg-primary text-primary-foreground"
                  : "text-muted-foreground hover:text-primary"
              }`}
            >
              {o.l}
            </button>
          ))}
        </div>
      </div>

      <SelectField
        label="Cidade"
        value={filters.city}
        onChange={(v) => set("city", v)}
        options={cities}
        placeholder="Todas"
      />
      <SelectField
        label="Bairro"
        value={filters.neighborhood}
        onChange={(v) => set("neighborhood", v)}
        options={neighborhoods}
        placeholder="Todos"
      />
      <SelectField
        label="Condomínio"
        value={filters.condo}
        onChange={(v) => set("condo", v)}
        options={condos}
        placeholder="Todos"
      />
      <SelectField
        label="Tipo"
        value={filters.type}
        onChange={(v) => set("type", v)}
        options={propertyTypes}
        placeholder="Todos"
      />

      <div className="grid grid-cols-2 gap-3">
        <NumField
          label="Preço mínimo"
          value={filters.minPrice}
          onChange={(v) => set("minPrice", v)}
        />
        <NumField
          label="Preço máximo"
          value={filters.maxPrice}
          onChange={(v) => set("maxPrice", v)}
        />
        <NumField
          label="Área mínima (m²)"
          value={filters.minArea}
          onChange={(v) => set("minArea", v)}
        />
        <NumField
          label="Área máxima (m²)"
          value={filters.maxArea}
          onChange={(v) => set("maxArea", v)}
        />
      </div>

      <div className="grid grid-cols-2 gap-3">
        <CountField label="Quartos" value={filters.bedrooms} onChange={(v) => set("bedrooms", v)} />
        <CountField label="Suítes" value={filters.suites} onChange={(v) => set("suites", v)} />
        <CountField label="Banheiros" value={filters.baths} onChange={(v) => set("baths", v)} />
        <CountField label="Vagas" value={filters.parking} onChange={(v) => set("parking", v)} />
      </div>

      <div className="space-y-3 border-t border-border pt-5">
        {[
          { key: "furnished", label: "Imóvel mobiliado" },
          { key: "financing", label: "Aceita financiamento" },
          { key: "permuta", label: "Aceita permuta" },
          { key: "launch", label: "Lançamento" },
          { key: "exclusive", label: "Exclusividade" },
        ].map((o) => (
          <div key={o.key} className="flex items-center gap-2.5">
            <Checkbox
              id={`f-${o.key}`}
              checked={filters[o.key as keyof Filters] as boolean}
              onCheckedChange={(c) => set(o.key as keyof Filters, Boolean(c) as never)}
            />
            <Label htmlFor={`f-${o.key}`} className="text-sm font-normal text-foreground">
              {o.label}
            </Label>
          </div>
        ))}
      </div>

      <div className="space-y-2">
        <Label className="text-xs uppercase tracking-[0.1em] text-muted-foreground">
          Código do imóvel
        </Label>
        <Input
          className="h-10 rounded-xs"
          value={filters.code}
          onChange={(e) => set("code", e.target.value)}
          placeholder="VP1024"
        />
      </div>

      <Button
        variant="outline"
        className="w-full rounded-xs"
        onClick={() => setFilters(emptyFilters)}
      >
        Limpar filtros
      </Button>
    </div>
  );

  return (
    <div className="container-page py-10">
      <nav aria-label="Você está aqui" className="text-xs text-muted-foreground">
        <Link to="/" className="hover:text-primary">
          Início
        </Link>{" "}
        <span className="px-1">/</span> Imóveis
      </nav>

      <div className="mt-4 flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="text-2xl font-semibold text-foreground sm:text-3xl">
            Imóveis em São José dos Campos e região
          </h1>
          <p className="mt-2 text-sm text-muted-foreground">
            {results.length} {results.length === 1 ? "imóvel encontrado" : "imóveis encontrados"}
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <select
            className={`${selectClass} w-auto`}
            value={sort}
            onChange={(e) => setSort(e.target.value as SortKey)}
            aria-label="Ordenar resultados"
          >
            <option value="recentes">Mais recentes</option>
            <option value="menor-preco">Menor preço</option>
            <option value="maior-preco">Maior preço</option>
            <option value="maior-area">Maior área</option>
          </select>
          <div className="flex rounded-xs border border-border p-1">
            <button
              type="button"
              onClick={() => setView("grade")}
              aria-pressed={view === "grade"}
              className={`inline-flex items-center gap-1.5 rounded-xs px-3 py-1.5 text-xs font-medium ${view === "grade" ? "bg-primary text-primary-foreground" : "text-muted-foreground"}`}
            >
              <LayoutGrid className="h-3.5 w-3.5" /> Grade
            </button>
            <button
              type="button"
              onClick={() => setView("mapa")}
              aria-pressed={view === "mapa"}
              className={`inline-flex items-center gap-1.5 rounded-xs px-3 py-1.5 text-xs font-medium ${view === "mapa" ? "bg-primary text-primary-foreground" : "text-muted-foreground"}`}
            >
              <MapIcon className="h-3.5 w-3.5" /> Mapa
            </button>
          </div>
          <Button
            variant="outline"
            className="rounded-xs lg:hidden"
            onClick={() => setDrawer(true)}
          >
            <Filter className="mr-2 h-4 w-4" /> Filtros
            {countActive(filters) > 0 && (
              <span className="ml-1.5 text-primary">({countActive(filters)})</span>
            )}
          </Button>
        </div>
      </div>

      <div className="mt-8 grid gap-8 lg:grid-cols-[280px_1fr]">
        <aside className="hidden lg:block">
          <div className="sticky top-24 rounded-sm border border-border bg-card p-5">{panel}</div>
        </aside>

        <div>
          {view === "mapa" ? (
            <div className="rounded-sm border border-border bg-surface p-6">
              <p className="text-sm text-muted-foreground">
                Visualização em mapa com os {results.length} imóveis do filtro atual, agrupados por
                bairro.
              </p>
              <div className="mt-5 grid gap-3 sm:grid-cols-2">
                {Object.entries(
                  results.reduce<Record<string, number>>((acc, p) => {
                    acc[p.neighborhood] = (acc[p.neighborhood] ?? 0) + 1;
                    return acc;
                  }, {}),
                ).map(([name, count]) => (
                  <div
                    key={name}
                    className="flex items-center justify-between rounded-xs border border-border bg-card px-4 py-3 text-sm"
                  >
                    <span className="font-medium text-foreground">{name}</span>
                    <span className="text-muted-foreground">{count} imóveis</span>
                  </div>
                ))}
              </div>
            </div>
          ) : loading ? (
            <div className="grid gap-6 sm:grid-cols-2 xl:grid-cols-3">
              {Array.from({ length: 6 }).map((_, i) => (
                <PropertyCardSkeleton key={i} />
              ))}
            </div>
          ) : results.length === 0 ? (
            <div className="rounded-sm border border-dashed border-border p-12 text-center">
              <p className="font-display text-lg font-semibold text-foreground">
                Nenhum imóvel com esses filtros
              </p>
              <p className="mx-auto mt-2 max-w-md text-sm text-muted-foreground">
                Tente ampliar a faixa de preço ou remover algum filtro. Também podemos buscar na
                nossa carteira interna.
              </p>
              <Button className="mt-6 rounded-xs" onClick={() => setFilters(emptyFilters)}>
                Limpar filtros
              </Button>
            </div>
          ) : (
            <>
              <div className="grid gap-6 sm:grid-cols-2 xl:grid-cols-3">
                {results.slice(0, visible).map((p) => (
                  <PropertyCard key={p.id} property={p} />
                ))}
              </div>
              {visible < results.length && (
                <div className="mt-10 text-center">
                  <Button
                    variant="outline"
                    className="rounded-xs"
                    onClick={() => setVisible((v) => v + PAGE_SIZE)}
                  >
                    Carregar mais imóveis
                  </Button>
                </div>
              )}
            </>
          )}
        </div>
      </div>

      {drawer && (
        <div className="fixed inset-0 z-50 lg:hidden">
          <div className="absolute inset-0 bg-navy-deep/50" onClick={() => setDrawer(false)} />
          <div className="absolute inset-y-0 right-0 flex w-[88%] max-w-sm flex-col bg-background">
            <div className="flex items-center justify-between border-b border-border px-5 py-4">
              <span className="font-display font-semibold text-foreground">Filtros</span>
              <button
                onClick={() => setDrawer(false)}
                aria-label="Fechar filtros"
                className="text-muted-foreground"
              >
                <X className="h-5 w-5" />
              </button>
            </div>
            <div className="flex-1 overflow-y-auto p-5">{panel}</div>
            <div className="border-t border-border p-4">
              <Button className="w-full rounded-xs" onClick={() => setDrawer(false)}>
                Ver {results.length} imóveis
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function SelectField({
  label,
  value,
  onChange,
  options,
  placeholder,
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  options: readonly string[];
  placeholder: string;
}) {
  return (
    <div className="space-y-2">
      <Label className="text-xs uppercase tracking-[0.1em] text-muted-foreground">{label}</Label>
      <select className={selectClass} value={value} onChange={(e) => onChange(e.target.value)}>
        <option value="">{placeholder}</option>
        {options.map((o) => (
          <option key={o} value={o}>
            {o}
          </option>
        ))}
      </select>
    </div>
  );
}

function NumField({
  label,
  value,
  onChange,
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
}) {
  return (
    <div className="space-y-2">
      <Label className="text-xs text-muted-foreground">{label}</Label>
      <Input
        inputMode="numeric"
        className="h-10 rounded-xs"
        value={value}
        onChange={(e) => onChange(e.target.value.replace(/\D/g, ""))}
        placeholder="—"
      />
    </div>
  );
}

function CountField({
  label,
  value,
  onChange,
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
}) {
  return (
    <div className="space-y-2">
      <Label className="text-xs text-muted-foreground">{label}</Label>
      <select className={selectClass} value={value} onChange={(e) => onChange(e.target.value)}>
        <option value="">Todos</option>
        {[1, 2, 3, 4].map((n) => (
          <option key={n} value={String(n)}>
            {n}+
          </option>
        ))}
      </select>
    </div>
  );
}
