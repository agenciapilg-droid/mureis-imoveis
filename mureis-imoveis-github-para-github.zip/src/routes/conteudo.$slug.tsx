import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { articles } from "@/data/properties";

export const Route = createFileRoute("/conteudo/$slug")({
  loader: ({ params }) => {
    const article = articles.find((a) => a.slug === params.slug);
    if (!article) throw notFound();
    return { article };
  },
  head: ({ loaderData, params }) => {
    if (!loaderData)
      return {
        meta: [{ title: "Conteúdo não encontrado" }, { name: "robots", content: "noindex" }],
      };
    const a = loaderData.article;
    return {
      meta: [
        { title: `${a.title} | Mureis Imóveis` },
        { name: "description", content: a.excerpt },
        { property: "og:title", content: a.title },
        { property: "og:description", content: a.excerpt },
        { property: "og:type", content: "article" },
        { property: "og:url", content: `/conteudo/${params.slug}` },
      ],
      links: [{ rel: "canonical", href: `/conteudo/${params.slug}` }],
    };
  },
  notFoundComponent: () => (
    <div className="container-page py-24 text-center">
      <h1 className="text-2xl font-semibold text-foreground">Conteúdo não encontrado</h1>
      <Link to="/" className="mt-4 inline-block text-sm text-primary">
        Voltar ao início
      </Link>
    </div>
  ),
  component: ArticlePage,
});

function ArticlePage() {
  const { article } = Route.useLoaderData() as { article: (typeof articles)[number] };
  return (
    <article className="container-page max-w-3xl py-12">
      <p className="eyebrow">{article.category}</p>
      <h1 className="mt-3 text-3xl font-semibold leading-tight text-foreground">{article.title}</h1>
      <p className="mt-2 text-xs text-muted-foreground">{article.readingTime}</p>
      <img
        src={article.image}
        alt={article.title}
        loading="lazy"
        className="mt-8 aspect-[16/9] w-full rounded-sm object-cover"
      />
      <p className="mt-8 leading-relaxed text-muted-foreground">{article.excerpt}</p>
      <p className="mt-4 leading-relaxed text-muted-foreground">
        Este conteúdo faz parte da nossa série sobre o mercado imobiliário de São José dos Campos.
        Para uma análise aplicada ao seu caso, fale com um dos nossos especialistas por região.
      </p>
      <Link
        to="/contato"
        className="mt-8 inline-block text-sm font-medium text-primary hover:text-accent-foreground"
      >
        Falar com um especialista
      </Link>
    </article>
  );
}
