import { createFileRoute } from "@tanstack/react-router";
import { ChevronLeft, ChevronRight, Images, X } from "lucide-react";
import { useRef, useState } from "react";
import { Button } from "@/components/ui/button";
import { SectionHeading } from "@/components/site/SectionHeading";
import { launches } from "@/data/properties";
import { useVitorinoLaunch } from "@/hooks/use-supabase-content";
import { whatsappLink } from "@/data/site";
import { brl } from "@/lib/format";

const title = "Lançamentos imobiliários em São José dos Campos | Mureis Imóveis";
const description =
  "Empreendimentos em lançamento, em obras e prontos para morar em São José dos Campos, incluindo o Residencial Vitorino no Jardim Ismênia.";

export const Route = createFileRoute("/lancamentos")({
  head: () => ({
    meta: [
      { title },
      { name: "description", content: description },
      { property: "og:title", content: title },
      { property: "og:description", content: description },
      { property: "og:url", content: "/lancamentos" },
    ],
    links: [{ rel: "canonical", href: "/lancamentos" }],
  }),
  component: LaunchesPage,
});

function LaunchesPage() {
  const vitorino = useVitorinoLaunch();
  const displayed = launches.flatMap((launch) => launch.slug === "residencial-vitorino" ? (vitorino ? [vitorino] : []) : [launch]);
  return (
    <div className="container-page py-12">
      <SectionHeading
        eyebrow="Lançamentos"
        title="Lançamentos que antecipam o futuro da cidade"
        subtitle="Conheça os empreendimentos em destaque. Confirme valores e disponibilidade antes de tomar uma decisão."
      />
      <div className="mt-12 space-y-14">
        {displayed.map((l) => (
          <article key={l.slug} id={l.slug} className="grid scroll-mt-28 gap-8 lg:grid-cols-2">
            <LaunchGallery
              images={l.images?.length ? l.images : [l.image]}
              name={l.name}
              neighborhood={l.neighborhood}
            />
            <div className="self-center">
              <span className="rounded-xs border border-accent/60 px-2 py-0.5 text-[0.68rem] font-semibold uppercase tracking-[0.1em] text-accent-foreground">
                {l.stage}
              </span>
              <h2 className="mt-4 text-2xl font-semibold text-foreground">{l.name}</h2>
              <p className="mt-1 text-sm text-muted-foreground">
                {l.address ?? `${l.neighborhood}, ${l.city}`}
              </p>
              <dl className="mt-6 grid gap-3 sm:grid-cols-3">
                <div>
                  <dt className="text-xs text-muted-foreground">Tipologias</dt>
                  <dd className="text-sm font-medium text-foreground">{l.typologies}</dd>
                </div>
                <div>
                  <dt className="text-xs text-muted-foreground">Área</dt>
                  <dd className="text-sm font-medium text-foreground">{l.area}</dd>
                </div>
                <div>
                  <dt className="text-xs text-muted-foreground">A partir de</dt>
                  <dd className="font-display text-sm font-bold text-primary">
                    {brl(l.priceFrom)}
                  </dd>
                </div>
              </dl>
              <ul className="mt-6 grid gap-2 sm:grid-cols-2">
                {l.highlights.map((h) => (
                  <li key={h} className="flex items-center gap-2 text-sm text-muted-foreground">
                    <span className="h-1.5 w-1.5 rounded-full bg-accent" /> {h}
                  </li>
                ))}
              </ul>
              <div className="mt-8 flex flex-wrap gap-3">
                <Button asChild className="rounded-xs bg-[#25D366] font-semibold text-white hover:bg-[#1fbd59]">
                  <a
                    href={whatsappLink(`Olá! Gostaria de receber mais informações sobre o empreendimento ${l.name}, no bairro ${l.neighborhood}.`)}
                    target="_blank"
                    rel="noreferrer"
                  >
                    Conhecer empreendimento
                  </a>
                </Button>
              </div>
            </div>
          </article>
        ))}
      </div>
    </div>
  );
}

function LaunchGallery({ images, name, neighborhood }: { images: string[]; name: string; neighborhood: string }) {
  const [open, setOpen] = useState(false);
  const scroller = useRef<HTMLDivElement>(null);
  const move = (direction: number) => scroller.current?.scrollBy({ left: direction * scroller.current.clientWidth, behavior: "smooth" });

  return (
    <>
      <button
        type="button"
        onClick={() => setOpen(true)}
        className="group relative aspect-[4/3] overflow-hidden bg-muted text-left sm:aspect-[16/11]"
        aria-label={`Abrir fotos do ${name}`}
      >
        <img src={images[0]} alt={`${name} — ${neighborhood}`} loading="lazy" className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-[1.025]" />
        <span className="absolute bottom-4 right-4 inline-flex items-center gap-2 bg-primary/88 px-3 py-2 text-xs font-semibold text-primary-foreground backdrop-blur-sm">
          <Images className="h-4 w-4" /> {images.length > 1 ? `${images.length} fotos` : "Ampliar foto"}
        </span>
      </button>
      {open && (
        <div className="fixed inset-0 z-50 bg-navy-deep/95" role="dialog" aria-modal="true" aria-label={`Galeria do ${name}`}>
          <button type="button" onClick={() => setOpen(false)} className="absolute right-4 top-4 z-10 rounded-full bg-black/35 p-3 text-white" aria-label="Fechar galeria"><X className="h-6 w-6" /></button>
          <button type="button" onClick={() => move(-1)} className="absolute left-3 top-1/2 z-10 -translate-y-1/2 rounded-full bg-black/35 p-3 text-white" aria-label="Foto anterior"><ChevronLeft className="h-7 w-7" /></button>
          <div ref={scroller} className="flex h-full snap-x snap-mandatory overflow-x-auto overscroll-x-contain [scrollbar-width:none]">
            {images.map((image, index) => (
              <div key={`${image}-${index}`} className="flex h-full min-w-full snap-center items-center justify-center p-5 sm:p-10">
                <img src={image} alt={`${name} — foto ${index + 1}`} className="max-h-[86vh] max-w-full object-contain" />
              </div>
            ))}
          </div>
          <button type="button" onClick={() => move(1)} className="absolute right-3 top-1/2 z-10 -translate-y-1/2 rounded-full bg-black/35 p-3 text-white" aria-label="Próxima foto"><ChevronRight className="h-7 w-7" /></button>
        </div>
      )}
    </>
  );
}
