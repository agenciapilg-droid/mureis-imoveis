import { createFileRoute, redirect } from "@tanstack/react-router";

export const Route = createFileRoute("/alugar")({
  beforeLoad: () => {
    throw redirect({ to: "/imoveis", search: { purpose: "aluguel" } });
  },
});
