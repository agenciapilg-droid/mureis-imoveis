import { createFileRoute, Link } from "@tanstack/react-router";
import { SectionHeading } from "@/components/site/SectionHeading";
import { regions } from "@/data/properties";

function neighborhoodSlug(name: string) {
  return name.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase().replace(/\s+/g, "-");
}

const title = "Bairros de São José dos Campos | Mureis Imóveis";
const description =
  "Urbanova, Jardim Aquarius, Jardim das Colinas, Jardim do Golfe e outras regiões de São José dos Campos com imóveis disponíveis.";

export const Route = createFileRoute("/bairros")({
  head: () => ({
    meta: [
      { title },
      { name: "description", content: description },
      { property: "og:title", content: title },
      { property: "og:description", content: description },
      { property: "og:url", content: "/bairros" },
    ],
    links: [{ rel: "canonical", href: "/bairros" }],
  }),
  component: () => (
    <div className="container-page py-12">
      <SectionHeading
        eyebrow="Regiões"
        title="Explore São José dos Campos por região"
        subtitle="Selecione um bairro para ver os imóveis disponíveis e o perfil de cada região."
      />
      <div className="mt-10 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
        {regions.map((r) => (
          <article
            key={r.name}
            id={neighborhoodSlug(r.name)}
            className="group overflow-hidden rounded-sm border border-border bg-card"
          >
            <div className="aspect-[4/3] overflow-hidden bg-muted">
              <img
                src={r.image}
                alt={`Região ${r.name}`}
                loading="lazy"
                className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-[1.04]"
              />
            </div>
            <div className="p-4">
              <p className="font-display text-base font-semibold text-foreground">{r.name}</p>
              <p className="mt-1 text-xs text-muted-foreground">Guia e vlog do bairro em preparação</p>
              <Link
                to="/imoveis"
                search={{ neighborhood: r.name }}
                className="mt-3 inline-flex text-sm font-semibold text-primary"
              >
                Ver imóveis disponíveis
              </Link>
            </div>
          </article>
        ))}
      </div>
    </div>
  ),
});
