import { useCallback, useEffect, useState } from "react";

const FAV_KEY = "vimura:favoritos";
const CMP_KEY = "vimura:comparar";
const EVENT = "vimura:storage";

function read(key: string): string[] {
  if (typeof window === "undefined") return [];
  try {
    const raw = window.localStorage.getItem(key);
    const parsed = raw ? JSON.parse(raw) : [];
    return Array.isArray(parsed) ? (parsed as string[]) : [];
  } catch {
    return [];
  }
}

function write(key: string, value: string[]) {
  window.localStorage.setItem(key, JSON.stringify(value));
  window.dispatchEvent(new CustomEvent(EVENT));
}

function useList(key: string, max?: number) {
  const [ids, setIds] = useState<string[]>([]);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    const sync = () => setIds(read(key));
    sync();
    setReady(true);
    window.addEventListener(EVENT, sync);
    window.addEventListener("storage", sync);
    return () => {
      window.removeEventListener(EVENT, sync);
      window.removeEventListener("storage", sync);
    };
  }, [key]);

  const toggle = useCallback(
    (id: string) => {
      const current = read(key);
      if (current.includes(id)) {
        write(
          key,
          current.filter((x) => x !== id),
        );
        return false;
      }
      if (max && current.length >= max) return null;
      write(key, [...current, id]);
      return true;
    },
    [key, max],
  );

  const remove = useCallback(
    (id: string) =>
      write(
        key,
        read(key).filter((x) => x !== id),
      ),
    [key],
  );

  const clear = useCallback(() => write(key, []), [key]);

  return { ids, ready, toggle, remove, clear, has: (id: string) => ids.includes(id) };
}

export function useFavorites() {
  return useList(FAV_KEY);
}

export function useCompare() {
  return useList(CMP_KEY, 3);
}
