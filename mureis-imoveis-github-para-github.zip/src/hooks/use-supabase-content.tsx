import { createContext, useContext, useEffect, useState, type ReactNode } from "react";
import type { Launch, Property } from "@/data/properties";
import { launches, properties as fallbackProperties } from "@/data/properties";
import { organizationSlug, supabase } from "@/lib/supabase";
import fallbackPropertyImage from "@/assets/hero-home.jpg";

const typeLabels: Record<string, Property["type"]> = {
  standard_apartment: "Apartamento",
  studio: "Apartamento",
  kitnet: "Apartamento",
  loft: "Apartamento",
  flat: "Apartamento",
  penthouse: "Cobertura",
  garden: "Apartamento",
  single_story_house: "Casa",
  townhouse: "Casa",
  gated_community_house: "Casa em condomínio",
  village_house: "Casa",
  outbuilding: "Casa",
  small_farm: "Casa",
  farmstead: "Casa",
  farm: "Casa",
  ranch: "Casa",
};

export function mapProperty(row: any): Property {
  const price = row.sale_price ?? row.rent_price ?? row.seasonal_price ?? null;
  return {
    id: row.id,
    code: row.code,
    slug: row.slug,
    title: row.title,
    type: typeLabels[row.property_type] ?? "Casa",
    purpose: row.purpose === "rent" ? "aluguel" : "venda",
    city: row.city,
    neighborhood: row.neighborhood,
    condo: null,
    price,
    condoFee: row.condominium_fee,
    iptu: row.iptu_value,
    area: row.usable_area ?? 0,
    landArea: row.total_area,
    bedrooms: row.bedrooms ?? 0,
    suites: row.suites ?? 0,
    baths: row.bathrooms ?? 0,
    parking: row.parking_spaces ?? 0,
    badge: row.featured ? "Exclusivo" : null,
    featured: row.featured,
    isLaunch: false,
    exclusive: row.featured,
    furnished: row.furnished,
    financing: row.accepts_financing,
    permuta: row.accepts_exchange,
    createdAt: row.published_at ?? row.updated_at,
    description: row.description ?? "",
    features: row.features ?? [],
    condoFeatures: row.condominium_features ?? [],
    images: [row.cover_image_url || fallbackPropertyImage],
    broker: {
      name: "Equipe Mureis Imóveis",
      role: "Atendimento imobiliário",
      creci: "CRECI 283.017-F — Pedro Henrique Cardoso",
    },
  };
}

export function useSupabaseProperties() {
  const [properties, setProperties] = useState<Property[]>(fallbackProperties);
  const vitorino = useSiteSettings().home?.vitorino;
  useEffect(() => {
    supabase
      .from("published_properties")
      .select("*")
      .eq("organization_slug", organizationSlug)
      .order("featured_order", { ascending: true, nullsFirst: false })
      .then(({ data }) => {
        if (data?.length) setProperties(data.map(mapProperty));
      });
  }, []);
  const existing = properties.some((property) => isVitorino(property));
  const withVitorino = existing ? properties : [...properties, fallbackProperties.find(isVitorino)!];
  return withVitorino
    .filter((property) => !isVitorino(property) || vitorino?.visible !== false)
    .map((property) => isVitorino(property) ? applyVitorinoProperty(property, vitorino) : property);
}

export type VitorinoContent = Partial<{
  name: string; title: string; code: string; neighborhood: string; city: string;
  address: string; typologies: string; area: string; priceFrom: number;
  stage: Launch["stage"]; description: string; bedrooms: number; suites: number;
  bathrooms: number; parking: number; condoFee: number; iptu: number;
  highlights: string[]; features: string[]; images: string[]; visible: boolean;
}>;

export function isVitorino(property: Property) {
  return property.slug.includes("residencial-vitorino") || property.code === "MR-VITORINO";
}

export function applyVitorinoProperty(property: Property, data?: VitorinoContent): Property {
  if (!data) return property;
  const images = data.images?.length ? data.images : property.images;
  const area = Number.parseFloat(data.area?.replace(/[^\d,]/g, "").replace(",", ".") ?? "");
  return {
    ...property,
    code: data.code || property.code,
    title: data.title || property.title,
    condo: data.name || property.condo,
    city: data.city || property.city,
    neighborhood: data.neighborhood || property.neighborhood,
    price: Number(data.priceFrom) > 0 ? Number(data.priceFrom) : property.price,
    area: Number.isFinite(area) ? area : property.area,
    bedrooms: data.bedrooms ?? property.bedrooms,
    suites: data.suites ?? property.suites,
    baths: data.bathrooms ?? property.baths,
    parking: data.parking ?? property.parking,
    condoFee: data.condoFee ?? property.condoFee,
    iptu: data.iptu ?? property.iptu,
    description: data.description || property.description,
    features: data.features ?? property.features,
    condoFeatures: data.highlights ?? property.condoFeatures,
    images,
  };
}

export function applyVitorinoLaunch(data?: VitorinoContent): Launch {
  const fallback = launches.find((launch) => launch.slug === "residencial-vitorino")!;
  if (!data) return fallback;
  const images = data.images?.length ? data.images : fallback.images ?? [fallback.image];
  return {
    ...fallback,
    name: data.name || fallback.name,
    neighborhood: data.neighborhood || fallback.neighborhood,
    city: data.city || fallback.city,
    ...(data.address || fallback.address ? { address: data.address || fallback.address } : {}),
    typologies: data.typologies || fallback.typologies,
    area: data.area || fallback.area,
    priceFrom: Number(data.priceFrom) > 0 ? Number(data.priceFrom) : fallback.priceFrom,
    stage: data.stage === "Lançamento" || data.stage === "Em obras" || data.stage === "Pronto para morar" ? data.stage : fallback.stage,
    highlights: data.highlights ?? fallback.highlights,
    image: images[0]!, images,
  };
}

export function useVitorinoLaunch() {
  const data = useSiteSettings().home?.vitorino;
  return data?.visible === false ? null : applyVitorinoLaunch(data);
}

export type PublicSiteSettings = {
  theme?: {
    primaryColor?: string;
    accentColor?: string;
    backgroundColor?: string;
    headingFont?: string;
    bodyFont?: string;
    logoUrl?: string;
  };
  home?: {
    heroTitle?: string;
    heroSubtitle?: string;
    heroImage?: string;
    launchEyebrow?: string;
    launchButton?: string;
    featuredEyebrow?: string;
    featuredTitle?: string;
    featuredSubtitle?: string;
    featuredButton?: string;
    blogEyebrow?: string;
    blogTitle?: string;
    blogSubtitle?: string;
    blogButton?: string;
    aboutEyebrow?: string;
    aboutTitle?: string;
    aboutText?: string;
    aboutName?: string;
    aboutCreci?: string;
    aboutImage?: string;
    aboutButton?: string;
    ownersEyebrow?: string;
    ownersTitle?: string;
    ownersDescription?: string;
    ownersButton?: string;
    vitorino?: VitorinoContent;
  };
  contact?: Record<string, string>;
};

export function useSupabaseSiteSettings() {
  const [settings, setSettings] = useState<PublicSiteSettings>({});
  useEffect(() => {
    supabase
      .from("public_organizations")
      .select("id")
      .eq("slug", organizationSlug)
      .single()
      .then(({ data }) => {
        if (!data) return;
        supabase
          .from("site_settings")
          .select("theme,home,contact")
          .eq("organization_id", data.id)
          .single()
          .then(({ data: siteData }) => siteData && setSettings(siteData));
      });
  }, []);
  return settings;
}

const SiteSettingsContext = createContext<PublicSiteSettings>({});

export function SiteSettingsProvider({ children }: { children: ReactNode }) {
  const settings = useSupabaseSiteSettings();

  useEffect(() => {
    const theme = settings.theme;
    if (!theme) return;
    const colors = [
      ["--primary", theme.primaryColor],
      ["--accent", theme.accentColor],
      ["--background", theme.backgroundColor],
    ] as const;
    for (const [property, color] of colors) {
      if (color && /^#[\da-f]{6}$/i.test(color)) document.documentElement.style.setProperty(property, color);
    }
    const headings: Record<string, string> = {
      "Playfair Display": '"Playfair Display", Georgia, serif',
      "Cormorant Garamond": '"Cormorant Garamond", Georgia, serif',
    };
    const bodies: Record<string, string> = {
      "Plus Jakarta Sans": '"Plus Jakarta Sans", system-ui, sans-serif',
      Inter: '"Inter", system-ui, sans-serif',
    };
    const heading = theme.headingFont ? headings[theme.headingFont] : undefined;
    const body = theme.bodyFont ? bodies[theme.bodyFont] : undefined;
    if (heading) document.documentElement.style.setProperty("--site-heading-font", heading);
    if (body) document.documentElement.style.setProperty("--site-body-font", body);
  }, [settings]);

  return <SiteSettingsContext.Provider value={settings}>{children}</SiteSettingsContext.Provider>;
}

export function useSiteSettings() {
  return useContext(SiteSettingsContext);
}
