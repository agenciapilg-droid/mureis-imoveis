import { createClient } from "@supabase/supabase-js";

const url = import.meta.env["VITE_SUPABASE_URL"] ?? "https://ysqlogiergczvdbkdgld.supabase.co";
const key =
  import.meta.env["VITE_SUPABASE_PUBLISHABLE_KEY"] ??
  "sb_publishable_vKQt9WgaRYBydFQQTiSnxg_KFQv9Ujm";

export const supabase = createClient(url, key);
export const organizationSlug = "mureis-imoveis";
