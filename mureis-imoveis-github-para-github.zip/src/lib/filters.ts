import type { Property, Purpose } from "@/data/properties";

export type Filters = {
  purpose: Purpose | "";
  type: string;
  city: string;
  neighborhood: string;
  condo: string;
  code: string;
  minPrice: string;
  maxPrice: string;
  bedrooms: string;
  suites: string;
  baths: string;
  parking: string;
  minArea: string;
  maxArea: string;
  furnished: boolean;
  financing: boolean;
  permuta: boolean;
  launch: boolean;
  exclusive: boolean;
};

export const emptyFilters: Filters = {
  purpose: "",
  type: "",
  city: "",
  neighborhood: "",
  condo: "",
  code: "",
  minPrice: "",
  maxPrice: "",
  bedrooms: "",
  suites: "",
  baths: "",
  parking: "",
  minArea: "",
  maxArea: "",
  furnished: false,
  financing: false,
  permuta: false,
  launch: false,
  exclusive: false,
};

export type SortKey = "recentes" | "menor-preco" | "maior-preco" | "maior-area";

const num = (v: string) => (v.trim() === "" ? null : Number(v.replace(/\D/g, "")));

export function applyFilters(list: Property[], f: Filters) {
  return list.filter((p) => {
    if (f.purpose && p.purpose !== f.purpose) return false;
    if (f.type && p.type !== f.type) return false;
    if (f.city && p.city !== f.city) return false;
    if (f.neighborhood && p.neighborhood !== f.neighborhood) return false;
    if (f.condo && p.condo !== f.condo) return false;
    if (f.code && !p.code.toLowerCase().includes(f.code.trim().toLowerCase())) return false;

    const min = num(f.minPrice);
    const max = num(f.maxPrice);
    if (min !== null && (p.price ?? 0) < min) return false;
    if (max !== null && (p.price ?? 0) > max) return false;

    const minA = num(f.minArea);
    const maxA = num(f.maxArea);
    if (minA !== null && p.area < minA) return false;
    if (maxA !== null && p.area > maxA) return false;

    const gte = (value: number, raw: string) => raw === "" || value >= Number(raw);
    if (!gte(p.bedrooms, f.bedrooms)) return false;
    if (!gte(p.suites, f.suites)) return false;
    if (!gte(p.baths, f.baths)) return false;
    if (!gte(p.parking, f.parking)) return false;

    if (f.furnished && !p.furnished) return false;
    if (f.financing && !p.financing) return false;
    if (f.permuta && !p.permuta) return false;
    if (f.launch && !p.isLaunch) return false;
    if (f.exclusive && !p.exclusive) return false;
    return true;
  });
}

export function sortProperties(list: Property[], key: SortKey) {
  const copy = [...list];
  switch (key) {
    case "menor-preco":
      return copy.sort((a, b) => (a.price ?? Infinity) - (b.price ?? Infinity));
    case "maior-preco":
      return copy.sort((a, b) => (b.price ?? 0) - (a.price ?? 0));
    case "maior-area":
      return copy.sort((a, b) => b.area - a.area);
    default:
      return copy.sort((a, b) => b.createdAt.localeCompare(a.createdAt));
  }
}

export function filtersFromSearch(search: Record<string, unknown>): Filters {
  const get = (k: keyof Filters) => {
    const v = search[k as string];
    return typeof v === "string" ? v : "";
  };
  const bool = (k: keyof Filters) => search[k as string] === "true" || search[k as string] === true;
  return {
    ...emptyFilters,
    purpose: (get("purpose") as Purpose | "") ?? "",
    type: get("type"),
    city: get("city"),
    neighborhood: get("neighborhood"),
    condo: get("condo"),
    code: get("code"),
    minPrice: get("minPrice"),
    maxPrice: get("maxPrice"),
    bedrooms: get("bedrooms"),
    suites: get("suites"),
    baths: get("baths"),
    parking: get("parking"),
    minArea: get("minArea"),
    maxArea: get("maxArea"),
    furnished: bool("furnished"),
    financing: bool("financing"),
    permuta: bool("permuta"),
    launch: bool("launch"),
    exclusive: bool("exclusive"),
  };
}

export function countActive(f: Filters) {
  return Object.entries(f).filter(([, v]) => (typeof v === "boolean" ? v : v !== "")).length;
}
