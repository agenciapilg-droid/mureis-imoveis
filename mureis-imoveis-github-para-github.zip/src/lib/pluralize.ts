export const pluralize = (value: number, singular: string, plural: string) =>
  `${value} ${value === 1 ? singular : plural}`;

export const bedroomsLabel = (v: number) => pluralize(v, "dormitório", "dormitórios");
export const suitesLabel = (v: number) => pluralize(v, "suíte", "suítes");
export const parkingLabel = (v: number) => pluralize(v, "vaga", "vagas");
export const bathsLabel = (v: number) => pluralize(v, "banheiro", "banheiros");
