type Payload = Record<string, string | number | null | undefined>;

const UTM_KEYS = ["utm_source", "utm_medium", "utm_campaign", "utm_content", "utm_term"] as const;
const UTM_STORAGE_KEY = "vimura:utm";

export interface LeadTracking {
  utm_source?: string;
  utm_medium?: string;
  utm_campaign?: string;
  utm_content?: string;
  utm_term?: string;
}

export function captureUtm() {
  if (typeof window === "undefined") return;
  const params = new URLSearchParams(window.location.search);
  const found: LeadTracking = {};
  for (const key of UTM_KEYS) {
    const value = params.get(key);
    if (value) found[key] = value;
  }
  if (Object.keys(found).length === 0) return;
  try {
    window.sessionStorage.setItem(UTM_STORAGE_KEY, JSON.stringify(found));
  } catch {
    /* storage indisponível */
  }
}

export function getUtm(): LeadTracking {
  if (typeof window === "undefined") return {};
  try {
    const raw = window.sessionStorage.getItem(UTM_STORAGE_KEY);
    return raw ? (JSON.parse(raw) as LeadTracking) : {};
  } catch {
    return {};
  }
}

declare global {
  interface Window {
    dataLayer?: Record<string, unknown>[];
    fbq?: (...args: unknown[]) => void;
    gtag?: (...args: unknown[]) => void;
  }
}

const PIXEL_EVENTS: Record<string, string> = {
  search: "Search",
  view_property: "ViewContent",
  property_whatsapp_click: "Contact",
  property_visit_request: "Schedule",
  property_lead: "Lead",
  owner_evaluation_lead: "Lead",
  contact_lead: "Lead",
};

export function trackEvent(event: string, payload: Payload = {}) {
  if (typeof window === "undefined") return;
  const data = { ...payload, ...getUtm() };
  window.dataLayer = window.dataLayer ?? [];
  window.dataLayer.push({ event, ...data });
  const pixelEvent = PIXEL_EVENTS[event];
  if (pixelEvent) window.fbq?.("track", pixelEvent, data);
  window.gtag?.("event", event, data);
}
