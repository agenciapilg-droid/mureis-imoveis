import { Link, useNavigate } from "@tanstack/react-router";
import { Heart, Menu, MessageCircle, Phone, Search, X } from "lucide-react";
import { useEffect, useRef, useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useFavorites } from "@/hooks/use-saved-properties";
import { site, waMessages, whatsappLink } from "@/data/site";
import { trackEvent } from "@/lib/tracking";
import { useSiteSettings } from "@/hooks/use-supabase-content";

const nav = [
  { to: "/comprar", label: "Comprar" },
  { to: "/alugar", label: "Alugar" },
  { to: "/lancamentos", label: "Lançamentos" },
  { to: "/bairros", label: "Bairros" },
  { to: "/anuncie", label: "Anuncie seu imóvel" },
  { to: "/sobre", label: "Sobre" },
] as const;

export function Header() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [term, setTerm] = useState("");
  const inputRef = useRef<HTMLInputElement>(null);
  const navigate = useNavigate();
  const { ids } = useFavorites();
  const logoUrl = useSiteSettings().theme?.logoUrl;

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 12);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    if (searchOpen) inputRef.current?.focus();
  }, [searchOpen]);

  function submitSearch(e: React.FormEvent) {
    e.preventDefault();
    const value = term.trim();
    const isCode = /^[a-z]{2}\d+$/i.test(value);
    trackEvent("search", { term: value });
    navigate({
      to: "/imoveis",
      search: value ? (isCode ? { code: value } : { neighborhood: value }) : {},
    });
    setSearchOpen(false);
    setOpen(false);
    setTerm("");
  }

  return (
    <header
      className={`relative z-50 border-b bg-primary/95 text-primary-foreground backdrop-blur-xl transition-all duration-300 md:sticky md:top-0 ${
        scrolled ? "border-primary-foreground/15" : "border-transparent"
      }`}
    >
      <div className="container-page flex h-[72px] items-center justify-between gap-6 md:h-[80px]">
        <Link
          to="/"
          className="flex shrink-0 items-center"
          aria-label={`${site.name} — página inicial`}
        >
          {logoUrl ? (
            <img src={logoUrl} alt="" className="h-[58px] w-[100px] object-contain" />
          ) : (
            <span className="relative block h-[58px] w-[100px] overflow-hidden" aria-hidden="true">
              <img src="/mureis-logo-oficial.png" alt="" className="absolute left-[-42px] top-[-19px] max-w-none w-[182px]" />
            </span>
          )}
        </Link>

        <nav className="hidden items-center gap-8 xl:flex" aria-label="Navegação principal">
          {nav.map((item) => (
            <Link
              key={item.to}
              to={item.to}
              className="relative py-3 text-[0.8rem] font-medium tracking-[0.02em] text-primary-foreground/72 transition-colors after:absolute after:inset-x-0 after:bottom-1 after:h-px after:origin-left after:scale-x-0 after:bg-accent after:transition-transform hover:text-primary-foreground hover:after:scale-x-100"
              activeProps={{ className: "text-primary-foreground font-medium" }}
            >
              {item.label}
            </Link>
          ))}
        </nav>

        <div className="flex items-center gap-1.5">
          <button
            type="button"
            onClick={() => setSearchOpen((v) => !v)}
            aria-label="Buscar imóveis"
            aria-expanded={searchOpen}
            className="inline-flex h-11 w-11 items-center justify-center rounded-xs text-primary-foreground/72 transition-colors hover:text-primary-foreground"
          >
            <Search className="h-5 w-5" />
          </button>
          <Link
            to="/favoritos"
            className="relative inline-flex h-11 w-11 items-center justify-center rounded-xs text-primary-foreground/72 transition-colors hover:text-primary-foreground"
            aria-label={`Favoritos${ids.length ? ` (${ids.length})` : ""}`}
          >
            <Heart className="h-5 w-5" />
            {ids.length > 0 && (
              <span className="absolute right-1 top-1.5 flex h-4 min-w-4 items-center justify-center rounded-full bg-primary px-1 text-[0.625rem] font-semibold text-primary-foreground">
                {ids.length}
              </span>
            )}
          </Link>
          <Button
            asChild
            className="hidden h-11 rounded-none bg-accent px-6 text-accent-foreground hover:bg-accent/90 md:inline-flex"
            onClick={() => trackEvent("header_whatsapp_click")}
          >
            <a href={whatsappLink(waMessages.general)} target="_blank" rel="noreferrer">
              <MessageCircle className="mr-2 h-4 w-4" /> Contato
            </a>
          </Button>
          <button
            className="inline-flex h-11 w-11 items-center justify-center rounded-xs text-primary-foreground xl:hidden"
            onClick={() => setOpen((v) => !v)}
            aria-label={open ? "Fechar menu" : "Abrir menu"}
            aria-expanded={open}
          >
            {open ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </button>
        </div>
      </div>

      {searchOpen && (
        <div className="border-t border-border bg-background">
          <form onSubmit={submitSearch} className="container-page flex gap-2 py-4" role="search">
            <Input
              ref={inputRef}
              value={term}
              onChange={(e) => setTerm(e.target.value)}
              placeholder="Buscar por bairro, condomínio ou código"
              aria-label="Buscar por bairro, condomínio ou código"
              className="h-11 rounded-xs"
            />
            <Button type="submit" className="h-11 rounded-xs px-6">
              Buscar
            </Button>
          </form>
        </div>
      )}

      {open && (
        <div className="border-t border-border bg-background xl:hidden">
          <nav
            className="container-page flex flex-col py-2"
            aria-label="Navegação principal (mobile)"
          >
            {nav.map((item) => (
              <Link
                key={item.to}
                to={item.to}
                onClick={() => setOpen(false)}
                className="border-b border-border/60 py-3.5 text-sm text-foreground last:border-0"
              >
                {item.label}
              </Link>
            ))}
            <div className="flex gap-2 py-4">
              <Button asChild className="h-12 flex-1 rounded-xs">
                <a href={whatsappLink(waMessages.general)} target="_blank" rel="noreferrer">
                  <MessageCircle className="mr-2 h-4 w-4" /> Contato
                </a>
              </Button>
            </div>
          </nav>
        </div>
      )}
    </header>
  );
}
