import { Link } from "@tanstack/react-router";
import { MapPin, MessageCircle, Phone } from "lucide-react";
import { site, whatsappLink } from "@/data/site";
import { useSiteSettings } from "@/hooks/use-supabase-content";

const columns = [
  {
    title: "Imóveis",
    links: [
      { to: "/comprar", label: "Comprar" },
      { to: "/alugar", label: "Alugar" },
      { to: "/lancamentos", label: "Lançamentos" },
      { to: "/bairros", label: "Bairros" },
    ],
  },
  {
    title: "Institucional",
    links: [
      { to: "/anuncie", label: "Anuncie seu imóvel" },
      { to: "/sobre", label: "Sobre" },
      { to: "/contato", label: "Contato" },
      { to: "/favoritos", label: "Favoritos" },
    ],
  },
] as const;

export function Footer() {
  const logoUrl = useSiteSettings().theme?.logoUrl;
  return (
    <footer className="border-t border-border bg-primary text-primary-foreground">
      <div className="container-page grid gap-10 py-12 md:grid-cols-[1.4fr_1fr_1fr_1.2fr]">
        <div>
          {logoUrl ? (
            <img src={logoUrl} alt={site.name} className="h-[70px] w-[120px] object-contain" />
          ) : (
            <div className="relative h-[70px] w-[120px] overflow-hidden" role="img" aria-label={site.name}>
              <img src="/mureis-logo-oficial.png" alt="" className="absolute left-[-49px] top-[-22px] max-w-none w-[210px]" />
            </div>
          )}
          <p className="mt-3 max-w-xs text-sm leading-relaxed text-primary-foreground/70">
            Imobiliária em São José dos Campos e região. Residenciais, lançamentos, terrenos e
            locações com atendimento consultivo.
          </p>
          <p className="mt-4 text-xs text-primary-foreground/60">{site.creci}</p>
        </div>

        {columns.map((col) => (
          <div key={col.title}>
            <h3 className="text-xs font-semibold uppercase tracking-[0.14em] text-primary-foreground/50">
              {col.title}
            </h3>
            <ul className="mt-4 space-y-2.5">
              {col.links.map((l) => (
                <li key={l.to}>
                  <Link
                    to={l.to}
                    className="text-sm text-primary-foreground/80 transition-colors hover:text-accent"
                  >
                    {l.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>
        ))}

        <div>
          <h3 className="text-xs font-semibold uppercase tracking-[0.14em] text-primary-foreground/50">
            Contato
          </h3>
          <ul className="mt-4 space-y-2.5 text-sm text-primary-foreground/80">
            <li>
              <a
                className="inline-flex items-center gap-2 hover:text-accent"
                href={whatsappLink("Olá, vim pelo site da Mureis Imóveis.")}
                target="_blank"
                rel="noreferrer"
              >
                <MessageCircle className="h-4 w-4" /> Contato
              </a>
            </li>
            {site.phone && <li>
              <a
                className="inline-flex items-center gap-2 hover:text-accent"
                href={`tel:${site.phoneRaw}`}
              >
                <Phone className="h-4 w-4" /> {site.phone}
              </a>
            </li>}
            <li className="flex gap-2 pt-1 text-primary-foreground/60">
              <MapPin className="mt-0.5 h-4 w-4 shrink-0" />
              <span>{site.address}</span>
            </li>
          </ul>
        </div>
      </div>

      <div className="border-t border-primary-foreground/10">
        <div className="container-page flex flex-col gap-2 py-5 text-xs text-primary-foreground/55 sm:flex-row sm:items-center sm:justify-between">
          <span>© {new Date().getFullYear()} Mureis Imóveis. Todos os direitos reservados.</span>
          <div className="flex gap-5">
            <Link to="/privacidade" className="hover:text-accent">
              Política de privacidade
            </Link>
            <Link to="/termos" className="hover:text-accent">
              Termos de uso
            </Link>
          </div>
        </div>
      </div>
    </footer>
  );
}
