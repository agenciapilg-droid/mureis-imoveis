import type { Testimonial } from "@/data/properties";

export function Testimonials({ items }: { items: Testimonial[] }) {
  if (items.length === 0) return null;

  return (
    <div className="grid gap-6 md:grid-cols-3">
      {items.map((t) => (
        <figure key={t.name} className="flex flex-col rounded-sm border border-border bg-card p-6">
          <blockquote className="flex-1 text-sm leading-relaxed text-foreground">
            “{t.text}”
          </blockquote>
          <figcaption className="mt-5 flex items-center gap-3 border-t border-border pt-4">
            {t.photo && (
              <img
                src={t.photo}
                alt={t.name}
                loading="lazy"
                width={40}
                height={40}
                className="h-10 w-10 rounded-full object-cover"
              />
            )}
            <div>
              <p className="text-sm font-semibold text-foreground">{t.name}</p>
              {(t.transactionType ?? t.neighborhood) && (
                <p className="text-xs text-muted-foreground">
                  {[t.transactionType, t.neighborhood].filter(Boolean).join(" · ")}
                </p>
              )}
            </div>
          </figcaption>
        </figure>
      ))}
    </div>
  );
}
