import { useState } from "react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { propertyTypes } from "@/data/properties";
import { site, whatsappLink } from "@/data/site";
import { supabase } from "@/lib/supabase";

const selectClass =
  "h-12 w-full rounded-none border border-input bg-background px-3 text-sm text-foreground outline-none focus-visible:border-primary focus-visible:ring-2 focus-visible:ring-primary/15";

export function OwnerForm() {
  const [sending, setSending] = useState(false);

  async function submit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const data = new FormData(event.currentTarget);
    const name = String(data.get("name") ?? "").trim();
    const phone = String(data.get("phone") ?? "").trim();
    const neighborhood = String(data.get("neighborhood") ?? "").trim();
    const type = String(data.get("type") ?? "").trim();
    const purpose = String(data.get("purpose") ?? "").trim();
    const details = String(data.get("details") ?? "").trim();
    const privacy = data.get("privacy") === "on";

    if (!name || !phone || !neighborhood || !type || !purpose) {
      toast.error("Preencha os campos obrigatórios.");
      return;
    }
    if (phone.replace(/\D/g, "").length < 10) {
      toast.error("Informe um telefone com DDD válido.");
      return;
    }
    if (!privacy) {
      toast.error("Confirme a leitura da Política de Privacidade.");
      return;
    }
    setSending(true);
    const message = [
      "Olá! Quero anunciar meu imóvel com a Mureis.",
      `Nome: ${name}`,
      `WhatsApp: ${phone}`,
      `Bairro: ${neighborhood}`,
      `Tipo: ${type}`,
      `Objetivo: ${purpose}`,
      details ? `Detalhes: ${details}` : "",
    ]
      .filter(Boolean)
      .join("\n");
    const { data: organization } = await supabase
      .from("public_organizations")
      .select("id")
      .eq("slug", "mureis-imoveis")
      .single();
    const { error } = await supabase.from("contact_submissions").insert({
      organization_id: organization?.id,
      source: "form",
      name,
      phone,
      message,
      consent_at: new Date().toISOString(),
      landing_path: window.location.pathname,
      metadata: { neighborhood, type, purpose, details },
    });
    if (error) {
      toast.error("Não foi possível enviar agora. Tente novamente.");
      setSending(false);
      return;
    }
    toast.success("Recebemos os dados do seu imóvel. A Mureis entrará em contato.");
    if (site.whatsapp) window.open(whatsappLink(message), "_blank", "noopener,noreferrer");
    event.currentTarget.reset();
    setSending(false);
  }

  return (
    <form onSubmit={submit} className="grid gap-x-5 gap-y-5 sm:grid-cols-2">
      <div className="space-y-1.5 sm:col-span-2">
        <Label htmlFor="owner-name">Nome completo *</Label>
        <Input id="owner-name" name="name" autoComplete="name" className="h-12 rounded-none" />
      </div>
      <div className="space-y-1.5">
        <Label htmlFor="owner-phone">WhatsApp *</Label>
        <Input
          id="owner-phone"
          name="phone"
          type="tel"
          inputMode="tel"
          autoComplete="tel"
          placeholder="(12) 99999-9999"
          className="h-12 rounded-none"
        />
      </div>
      <div className="space-y-1.5">
        <Label htmlFor="owner-neighborhood">Bairro *</Label>
        <Input id="owner-neighborhood" name="neighborhood" className="h-12 rounded-none" />
      </div>
      <div className="space-y-1.5">
        <Label htmlFor="owner-type">Tipo de imóvel *</Label>
        <select id="owner-type" name="type" defaultValue="" className={selectClass}>
          <option value="" disabled>
            Selecione
          </option>
          {propertyTypes.map((type) => (
            <option key={type} value={type}>
              {type}
            </option>
          ))}
        </select>
      </div>
      <div className="space-y-1.5">
        <Label htmlFor="owner-purpose">O que deseja fazer? *</Label>
        <select id="owner-purpose" name="purpose" defaultValue="" className={selectClass}>
          <option value="" disabled>
            Selecione
          </option>
          <option value="Vender">Vender</option>
          <option value="Alugar">Alugar</option>
        </select>
      </div>
      <div className="space-y-1.5 sm:col-span-2">
        <Label htmlFor="owner-details">Conte um pouco sobre o imóvel</Label>
        <Textarea
          id="owner-details"
          name="details"
          rows={4}
          placeholder="Metragem, dormitórios, condomínio e outras informações importantes."
          className="rounded-none"
        />
      </div>
      <div className="border-t border-border pt-5 sm:col-span-2">
        <label className="mb-4 flex items-start gap-3 text-sm leading-6 text-muted-foreground">
          <input name="privacy" type="checkbox" className="mt-1 size-4 accent-primary" />
          <span>
            Concordo com o uso dos dados para retorno do atendimento, conforme a{" "}
            <a
              href="/privacidade"
              className="font-medium text-primary underline underline-offset-4"
            >
              Política de Privacidade
            </a>
            .
          </span>
        </label>
        <Button
          type="submit"
          disabled={sending}
          className="h-13 w-full rounded-none bg-[#25D366] px-6 font-semibold text-white hover:bg-[#1fbd59] sm:w-auto sm:min-w-64"
        >
          {sending ? "Abrindo WhatsApp..." : "Quero anunciar meu imóvel"}
        </Button>
      </div>
    </form>
  );
}
