import { useNavigate } from "@tanstack/react-router";
import { Search, SlidersHorizontal } from "lucide-react";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { cities, condos, neighborhoods, propertyTypes } from "@/data/properties";
import { trackEvent } from "@/lib/tracking";

const priceRanges = [
  { label: "Até R$ 500 mil", min: "", max: "500000" },
  { label: "R$ 500 mil a R$ 1 milhão", min: "500000", max: "1000000" },
  { label: "R$ 1 a 2 milhões", min: "1000000", max: "2000000" },
  { label: "Acima de R$ 2 milhões", min: "2000000", max: "" },
];

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="flex flex-col gap-1.5">
      <Label className="text-[0.7rem] font-medium uppercase tracking-[0.1em] text-muted-foreground">
        {label}
      </Label>
      {children}
    </div>
  );
}

const selectClass =
  "h-10 w-full rounded-none border-0 border-b border-input bg-transparent px-0 text-sm text-foreground outline-none transition-colors focus-visible:border-primary md:h-12";

const initial = {
  purpose: "venda",
  type: "",
  place: "",
  city: "São José dos Campos",
  range: "",
  bedrooms: "",
  suites: "",
  parking: "",
  minArea: "",
  code: "",
};

export function SearchForm() {
  const navigate = useNavigate();
  const [more, setMore] = useState(false);
  const [state, setState] = useState(initial);

  const set = (key: keyof typeof state, value: string) => setState((s) => ({ ...s, [key]: value }));

  function submit(e: React.FormEvent) {
    e.preventDefault();
    const range = priceRanges.find((r) => r.label === state.range);
    const search: Record<string, string> = {};
    const put = (k: string, v: string) => {
      if (v) search[k] = v;
    };
    put("purpose", state.purpose);
    put("type", state.type);
    if (state.place) {
      if (condos.includes(state.place)) put("condo", state.place);
      else put("neighborhood", state.place);
    }
    if (more) {
      put("city", state.city);
      put("bedrooms", state.bedrooms);
      put("suites", state.suites);
      put("parking", state.parking);
      put("minArea", state.minArea);
      put("code", state.code);
      if (range) {
        put("minPrice", range.min);
        put("maxPrice", range.max);
      }
    }
    trackEvent("search", { ...search });
    navigate({ to: "/imoveis", search });
  }

  return (
    <form
      onSubmit={submit}
      className="border border-border/80 bg-card p-3 text-foreground shadow-[0_24px_70px_-28px_rgba(8,20,48,0.65)] sm:p-6 lg:p-7"
      aria-label="Busca de imóveis"
    >
      <div className="grid grid-cols-2 gap-2 sm:gap-5 md:grid-cols-[auto_1fr_1.2fr_auto] md:items-end md:gap-7">
        <div className="col-span-2 md:col-span-1">
          <Field label="Finalidade">
            <div className="grid grid-cols-2 gap-1 border border-border p-1">
              {[
                { v: "venda", l: "Comprar" },
                { v: "aluguel", l: "Alugar" },
              ].map((o) => (
                <button
                  key={o.v}
                  type="button"
                  onClick={() => set("purpose", o.v)}
                  aria-pressed={state.purpose === o.v}
                  className={`h-10 rounded-none px-5 text-sm font-medium transition-colors ${
                    state.purpose === o.v
                      ? "bg-primary text-primary-foreground"
                      : "text-muted-foreground hover:text-primary"
                  }`}
                >
                  {o.l}
                </button>
              ))}
            </div>
          </Field>
        </div>

        <Field label="Tipo de imóvel">
          <select
            className={selectClass}
            value={state.type}
            onChange={(e) => set("type", e.target.value)}
            aria-label="Tipo de imóvel"
          >
            <option value="">Todos os tipos</option>
            {propertyTypes.map((t) => (
              <option key={t} value={t}>
                {t}
              </option>
            ))}
          </select>
        </Field>

        <Field label="Bairro ou condomínio">
          <select
            className={selectClass}
            value={state.place}
            onChange={(e) => set("place", e.target.value)}
            aria-label="Bairro ou condomínio"
          >
            <option value="">Todos os bairros</option>
            <optgroup label="Bairros">
              {neighborhoods.map((n) => (
                <option key={n} value={n}>
                  {n}
                </option>
              ))}
            </optgroup>
            <optgroup label="Condomínios">
              {condos.map((c) => (
                <option key={c} value={c}>
                  {c}
                </option>
              ))}
            </optgroup>
          </select>
        </Field>

        <Button type="submit" className="col-span-2 h-11 w-full rounded-none bg-primary px-8 md:col-span-1 md:h-12 md:w-auto">
          <Search className="mr-2 h-4 w-4" /> Buscar
        </Button>
      </div>

      {more && (
        <div className="mt-5 grid gap-4 border-t border-border pt-5 sm:grid-cols-2 lg:grid-cols-4">
          <Field label="Cidade">
            <select
              className={selectClass}
              value={state.city}
              onChange={(e) => set("city", e.target.value)}
              aria-label="Cidade"
            >
              <option value="">Todas as cidades</option>
              {cities.map((c) => (
                <option key={c} value={c}>
                  {c}
                </option>
              ))}
            </select>
          </Field>
          <Field label="Faixa de preço">
            <select
              className={selectClass}
              value={state.range}
              onChange={(e) => set("range", e.target.value)}
              aria-label="Faixa de preço"
            >
              <option value="">Qualquer valor</option>
              {priceRanges.map((r) => (
                <option key={r.label} value={r.label}>
                  {r.label}
                </option>
              ))}
            </select>
          </Field>
          <Field label="Dormitórios">
            <select
              className={selectClass}
              value={state.bedrooms}
              onChange={(e) => set("bedrooms", e.target.value)}
              aria-label="Dormitórios"
            >
              <option value="">Indiferente</option>
              {[1, 2, 3, 4].map((n) => (
                <option key={n} value={String(n)}>
                  {n}+
                </option>
              ))}
            </select>
          </Field>
          <Field label="Suítes">
            <select
              className={selectClass}
              value={state.suites}
              onChange={(e) => set("suites", e.target.value)}
              aria-label="Suítes"
            >
              <option value="">Indiferente</option>
              {[1, 2, 3].map((n) => (
                <option key={n} value={String(n)}>
                  {n}+
                </option>
              ))}
            </select>
          </Field>
          <Field label="Vagas">
            <select
              className={selectClass}
              value={state.parking}
              onChange={(e) => set("parking", e.target.value)}
              aria-label="Vagas"
            >
              <option value="">Indiferente</option>
              {[1, 2, 3, 4].map((n) => (
                <option key={n} value={String(n)}>
                  {n}+
                </option>
              ))}
            </select>
          </Field>
          <Field label="Área mínima (m²)">
            <Input
              className="h-12 rounded-xs"
              inputMode="numeric"
              value={state.minArea}
              onChange={(e) => set("minArea", e.target.value.replace(/\D/g, ""))}
              placeholder="Ex.: 80"
            />
          </Field>
          <Field label="Código do imóvel">
            <Input
              className="h-12 rounded-xs"
              placeholder="Ex.: VP1024"
              value={state.code}
              onChange={(e) => set("code", e.target.value)}
              maxLength={12}
            />
          </Field>
        </div>
      )}

      <div className="mt-4 flex items-center justify-between gap-3">
        <button
          type="button"
          onClick={() => setMore((v) => !v)}
          aria-expanded={more}
          aria-label={more ? "Ocultar filtros avançados" : "Abrir filtros avançados"}
          className="inline-flex items-center gap-2 text-sm font-medium text-muted-foreground transition-colors hover:text-primary"
        >
          <SlidersHorizontal className="h-4 w-4" />
          {more ? "Menos filtros" : "Mais filtros"}
        </button>
        {more && (
          <button
            type="button"
            onClick={() => setState(initial)}
            className="text-sm text-muted-foreground transition-colors hover:text-primary"
          >
            Limpar
          </button>
        )}
      </div>
    </form>
  );
}
