import { useEffect, useState } from "react";
import { Link } from "@tanstack/react-router";
import { Button } from "@/components/ui/button";

const STORAGE_KEY = "mureis-cookie-consent";

export function CookieConsent() {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    setVisible(!window.localStorage.getItem(STORAGE_KEY));
  }, []);

  if (!visible) return null;

  function save(value: "necessary" | "all") {
    window.localStorage.setItem(STORAGE_KEY, value);
    setVisible(false);
  }

  return (
    <aside
      aria-label="Preferências de cookies"
      className="fixed inset-x-4 bottom-4 z-[70] mx-auto max-w-3xl border border-border bg-background p-5 shadow-2xl sm:flex sm:items-center sm:gap-5"
    >
      <p className="flex-1 text-sm leading-6 text-muted-foreground">
        Usamos cookies necessários para o funcionamento do site. Métricas e campanhas só serão
        ativadas com sua autorização. Leia a{" "}
        <Link to="/privacidade" className="font-semibold text-primary underline underline-offset-4">
          Política de Privacidade
        </Link>
        .
      </p>
      <div className="mt-4 flex shrink-0 gap-2 sm:mt-0">
        <Button variant="outline" onClick={() => save("necessary")} className="rounded-none">
          Só necessários
        </Button>
        <Button onClick={() => save("all")} className="rounded-none">
          Aceitar
        </Button>
      </div>
    </aside>
  );
}
