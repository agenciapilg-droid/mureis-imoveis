import { Link } from "@tanstack/react-router";
import { BedDouble, Car, Heart, Maximize, Scale } from "lucide-react";
import { toast } from "sonner";
import type { Property } from "@/data/properties";
import { brl } from "@/lib/format";
import { bedroomsLabel, parkingLabel } from "@/lib/pluralize";
import { useCompare, useFavorites } from "@/hooks/use-saved-properties";

export function PropertyCard({ property }: { property: Property }) {
  const favorites = useFavorites();
  const compare = useCompare();
  const isFav = favorites.has(property.id);
  const isCmp = compare.has(property.id);

  return (
    <article className="group relative flex flex-col overflow-hidden border-b border-border bg-card transition-all duration-500 hover:-translate-y-1 hover:shadow-[0_24px_60px_-34px_rgba(8,20,48,0.45)]">
      <div className="relative aspect-[4/3] overflow-hidden bg-muted">
        <img
          src={property.images[0]}
          alt={`${property.type} em ${property.neighborhood}, ${property.city} — código ${property.code}`}
          loading="lazy"
          width={1200}
          height={800}
          className="h-full w-full object-cover transition-transform duration-700 ease-out group-hover:scale-[1.055]"
        />
        {property.badge && (
          <span className="absolute left-3 top-3 rounded-[0.2rem] bg-navy-deep/92 px-3 py-1.5 text-[0.62rem] font-semibold uppercase tracking-[0.16em] text-primary-foreground backdrop-blur">
            {property.badge}
          </span>
        )}
        <div className="absolute right-3 top-3 flex flex-col gap-2">
          <button
            type="button"
            aria-label={isFav ? "Remover dos favoritos" : "Adicionar aos favoritos"}
            aria-pressed={isFav}
            onClick={() => {
              const added = favorites.toggle(property.id);
              toast.success(added ? "Imóvel salvo nos favoritos" : "Imóvel removido dos favoritos");
            }}
            className="flex h-8 w-8 items-center justify-center rounded-full bg-background/95 text-primary transition-colors hover:bg-background"
          >
            <Heart className={`h-4 w-4 ${isFav ? "fill-current" : ""}`} />
          </button>
          <button
            type="button"
            aria-label={isCmp ? "Remover da comparação" : "Comparar imóvel"}
            aria-pressed={isCmp}
            onClick={() => {
              const added = compare.toggle(property.id);
              if (added === null) toast.error("Você pode comparar até três imóveis.");
              else
                toast.success(
                  added ? "Imóvel adicionado ao comparador" : "Imóvel removido do comparador",
                );
            }}
            className={`flex h-8 w-8 items-center justify-center rounded-full transition-colors ${
              isCmp
                ? "bg-primary text-primary-foreground"
                : "bg-background/95 text-primary hover:bg-background"
            }`}
          >
            <Scale className="h-4 w-4" />
          </button>
        </div>
        <div className="pointer-events-none absolute inset-x-3 bottom-3 opacity-0 transition-opacity duration-200 group-hover:opacity-100">
          <span className="inline-flex rounded-xs bg-primary px-3 py-1.5 text-xs font-medium text-primary-foreground">
            Ver imóvel
          </span>
        </div>
      </div>

      <div className="flex flex-1 flex-col px-1 py-5">
        <p className="text-[0.7rem] font-medium uppercase tracking-[0.12em] text-muted-foreground">
          {property.neighborhood} · {property.city}
        </p>
        <h3 className="mt-2.5 line-clamp-2 font-display text-[1.35rem] font-medium leading-tight text-foreground transition-colors group-hover:text-primary">
          <Link
            to="/imovel/$slug"
            params={{ slug: property.slug }}
            className="after:absolute after:inset-0"
          >
            {property.title}
          </Link>
        </h3>
        <p className="mt-4 text-lg font-semibold tracking-[-0.02em] text-primary">
          {brl(property.price)}
          {property.purpose === "aluguel" && (
            <span className="ml-1 text-sm font-medium text-muted-foreground">/mês</span>
          )}
        </p>

        <ul className="mt-4 flex flex-wrap items-center gap-x-4 gap-y-2 border-t border-border pt-3 text-xs text-muted-foreground">
          <li className="inline-flex items-center gap-1.5">
            <Maximize className="h-3.5 w-3.5" /> {property.area} m²
          </li>
          {property.bedrooms > 0 && (
            <li className="inline-flex items-center gap-1.5">
              <BedDouble className="h-3.5 w-3.5" /> {bedroomsLabel(property.bedrooms)}
            </li>
          )}
          {property.parking > 0 && (
            <li className="inline-flex items-center gap-1.5">
              <Car className="h-3.5 w-3.5" /> {parkingLabel(property.parking)}
            </li>
          )}
          <li className="ml-auto font-medium text-muted-foreground/80">{property.code}</li>
        </ul>
      </div>
    </article>
  );
}

export function PropertyCardSkeleton() {
  return (
    <div className="overflow-hidden rounded-sm border border-border">
      <div className="aspect-[4/3] animate-pulse bg-muted" />
      <div className="space-y-3 p-4">
        <div className="h-3 w-1/2 animate-pulse rounded-xs bg-muted" />
        <div className="h-4 w-4/5 animate-pulse rounded-xs bg-muted" />
        <div className="h-5 w-1/3 animate-pulse rounded-xs bg-muted" />
      </div>
    </div>
  );
}
