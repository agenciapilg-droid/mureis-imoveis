import urbanovaCasa from "@/assets/prop-urbanova-casa.jpg";
import aquariusApto from "@/assets/prop-aquarius-apto.jpg";
import golfeCasa from "@/assets/prop-golfe-casa.jpg";
import industrialApto from "@/assets/prop-industrial-apto.jpg";
import eucaliptosCobertura from "@/assets/prop-eucaliptos-cobertura.jpg";
import saoVicenteApto from "@/assets/prop-saovicente-apto.jpg";
import terrenoUrbanova from "@/assets/prop-terreno-urbanova.jpg";
import rudaCasa from "@/assets/prop-ruda-casa.jpg";
import ismeniaApto from "@/assets/prop-ismenia-apto.jpg";
import vitorino from "@/assets/lanc-vitorino.jpg";
import regiaoUrbanova from "@/assets/regiao-urbanova.jpg";
import regiaoAquarius from "@/assets/regiao-aquarius.jpg";
import regiaoColinas from "@/assets/regiao-colinas.jpg";
import blogFinanciamento from "@/assets/blog-financiamento.jpg";
import blogPlanta from "@/assets/blog-planta.jpg";

export type Purpose = "venda" | "aluguel";
export type PropertyType = "Casa em condomínio" | "Casa" | "Apartamento" | "Cobertura" | "Terreno";

export type Broker = {
  name: string;
  role: string;
  creci: string;
};

export type Property = {
  id: string;
  code: string;
  slug: string;
  title: string;
  type: PropertyType;
  purpose: Purpose;
  city: string;
  neighborhood: string;
  condo: string | null;
  price: number | null;
  condoFee: number | null;
  iptu: number | null;
  area: number;
  landArea: number | null;
  bedrooms: number;
  suites: number;
  baths: number;
  parking: number;
  badge: "Exclusivo" | "Lançamento" | "Oportunidade" | "Novo" | null;
  featured: boolean;
  isLaunch: boolean;
  exclusive: boolean;
  furnished: boolean;
  financing: boolean;
  permuta: boolean;
  createdAt: string;
  description: string;
  features: string[];
  condoFeatures: string[];
  images: string[];
  broker: Broker;
};

const brokers: Broker[] = Array.from({ length: 4 }, () => ({
  name: "Equipe Mureis Imóveis",
  role: "Atendimento imobiliário",
  creci: "CRECI 283.017-F — Pedro Henrique Cardoso",
}));

function gallery(main: string) {
  return [main];
}

export const properties: Property[] = [
  {
    id: "1",
    code: "VP1024",
    slug: "casa-condominio-urbanova-sao-jose-dos-campos-vp1024",
    title: "Casa térrea com pé-direito duplo em condomínio fechado",
    type: "Casa em condomínio",
    purpose: "venda",
    city: "São José dos Campos",
    neighborhood: "Urbanova",
    condo: "Condomínio Colinas do Paratehy",
    price: 2450000,
    condoFee: 980,
    iptu: 420,
    area: 312,
    landArea: 620,
    bedrooms: 4,
    suites: 3,
    baths: 5,
    parking: 4,
    badge: "Exclusivo",
    featured: true,
    isLaunch: false,
    exclusive: true,
    furnished: false,
    financing: true,
    permuta: true,
    createdAt: "2026-07-22",
    description:
      "Projeto contemporâneo em terreno plano, com integração total entre living, varanda gourmet e área de piscina. A suíte máster tem closet e vista para a mata preservada do condomínio. Acabamentos em porcelanato de grande formato, marcenaria planejada e iluminação embutida em todos os ambientes.",
    features: [
      "Piscina aquecida",
      "Varanda gourmet com churrasqueira",
      "Marcenaria planejada",
      "Aquecimento solar",
      "Ar-condicionado nos dormitórios",
      "Depósito e lavanderia independentes",
    ],
    condoFeatures: [
      "Portaria 24h",
      "Quadra poliesportiva",
      "Trilha e bosque",
      "Salão de festas",
      "Playground",
    ],
    images: gallery(urbanovaCasa),
    broker: brokers[0]!,
  },
  {
    id: "2",
    code: "VP1031",
    slug: "apartamento-jardim-aquarius-sao-jose-dos-campos-vp1031",
    title: "Apartamento reformado com vista livre e três vagas",
    type: "Apartamento",
    purpose: "venda",
    city: "São José dos Campos",
    neighborhood: "Jardim Aquarius",
    condo: "Edifício Vista Aquarius",
    price: 1290000,
    condoFee: 1150,
    iptu: 310,
    area: 148,
    landArea: null,
    bedrooms: 3,
    suites: 1,
    baths: 3,
    parking: 3,
    badge: "Oportunidade",
    featured: true,
    isLaunch: false,
    exclusive: false,
    furnished: false,
    financing: true,
    permuta: false,
    createdAt: "2026-07-18",
    description:
      "Andar alto, sol da manhã e vista permanente para o parque. Reforma concluída em 2025 com troca de piso, iluminação e bancadas. Localização a poucos minutos do Shopping Colinas e das principais avenidas da zona oeste.",
    features: [
      "Andar alto",
      "Vista livre",
      "Cozinha integrada",
      "Varanda com churrasqueira",
      "Armários planejados",
    ],
    condoFeatures: [
      "Piscina adulto e infantil",
      "Academia",
      "Salão de festas",
      "Portaria 24h",
      "Quadra",
    ],
    images: gallery(aquariusApto),
    broker: brokers[1]!,
  },
  {
    id: "3",
    code: "VP1042",
    slug: "casa-jardim-do-golfe-sao-jose-dos-campos-vp1042",
    title: "Casa com piscina e área de lazer integrada",
    type: "Casa",
    purpose: "venda",
    city: "São José dos Campos",
    neighborhood: "Jardim do Golfe",
    condo: null,
    price: 1690000,
    condoFee: null,
    iptu: 380,
    area: 245,
    landArea: 420,
    bedrooms: 3,
    suites: 2,
    baths: 4,
    parking: 3,
    badge: "Novo",
    featured: true,
    isLaunch: false,
    exclusive: false,
    furnished: false,
    financing: true,
    permuta: true,
    createdAt: "2026-07-30",
    description:
      "Casa em rua tranquila, com dois pavimentos bem distribuídos e área externa voltada ao lazer da família. Térreo com living amplo, lavabo e cozinha integrada ao deck da piscina; pavimento superior com três dormitórios e sacada.",
    features: ["Piscina", "Deck em madeira", "Cozinha integrada", "Sacada", "Portão automático"],
    condoFeatures: [],
    images: gallery(golfeCasa),
    broker: brokers[2]!,
  },
  {
    id: "4",
    code: "VP1055",
    slug: "apartamento-parque-industrial-sao-jose-dos-campos-vp1055",
    title: "Apartamento de dois dormitórios pronto para morar",
    type: "Apartamento",
    purpose: "venda",
    city: "São José dos Campos",
    neighborhood: "Parque Industrial",
    condo: "Residencial Parque Vitória",
    price: 385000,
    condoFee: 420,
    iptu: 120,
    area: 62,
    landArea: null,
    bedrooms: 2,
    suites: 1,
    baths: 2,
    parking: 1,
    badge: "Oportunidade",
    featured: true,
    isLaunch: false,
    exclusive: false,
    furnished: false,
    financing: true,
    permuta: false,
    createdAt: "2026-06-28",
    description:
      "Unidade em bloco reservado, com sol da tarde e planta bem aproveitada. Condomínio com custo baixo e acesso rápido à Dutra, ao Vale Sul Shopping e ao centro empresarial da região.",
    features: ["Armários na cozinha", "Sacada", "Sol da tarde", "Piso em porcelanato"],
    condoFeatures: ["Portaria 24h", "Salão de festas", "Playground", "Churrasqueira coletiva"],
    images: gallery(industrialApto),
    broker: brokers[2]!,
  },
  {
    id: "5",
    code: "VP1067",
    slug: "cobertura-bosque-dos-eucaliptos-sao-jose-dos-campos-vp1067",
    title: "Cobertura duplex com terraço e vista para a Serra",
    type: "Cobertura",
    purpose: "venda",
    city: "São José dos Campos",
    neighborhood: "Bosque dos Eucaliptos",
    condo: "Residencial Alto do Bosque",
    price: 980000,
    condoFee: 760,
    iptu: 260,
    area: 186,
    landArea: null,
    bedrooms: 3,
    suites: 1,
    baths: 3,
    parking: 2,
    badge: "Exclusivo",
    featured: true,
    isLaunch: false,
    exclusive: true,
    furnished: true,
    financing: true,
    permuta: false,
    createdAt: "2026-07-05",
    description:
      "Cobertura com pavimento superior inteiramente dedicado ao lazer: terraço com deck, piscina e espaço gourmet coberto. O pavimento inferior mantém três dormitórios e living social com dois ambientes.",
    features: [
      "Terraço privativo",
      "Piscina na cobertura",
      "Espaço gourmet",
      "Mobiliada",
      "Dois ambientes no living",
    ],
    condoFeatures: ["Portaria 24h", "Academia", "Salão de festas", "Quadra"],
    images: gallery(eucaliptosCobertura),
    broker: brokers[2]!,
  },
  {
    id: "6",
    code: "VP1073",
    slug: "apartamento-jardim-sao-vicente-sao-jose-dos-campos-vp1073",
    title: "Apartamento mobiliado para locação, próximo ao centro",
    type: "Apartamento",
    purpose: "aluguel",
    city: "São José dos Campos",
    neighborhood: "Jardim São Vicente",
    condo: "Edifício Alameda",
    price: 2400,
    condoFee: 390,
    iptu: 95,
    area: 54,
    landArea: null,
    bedrooms: 2,
    suites: 0,
    baths: 1,
    parking: 1,
    badge: "Novo",
    featured: true,
    isLaunch: false,
    exclusive: false,
    furnished: true,
    financing: false,
    permuta: false,
    createdAt: "2026-07-26",
    description:
      "Apartamento entregue mobiliado, com cozinha equipada e ambientes prontos para uso imediato. Indicado para quem vem trabalhar na região e busca praticidade, com transporte e comércio no entorno.",
    features: ["Mobiliado", "Cozinha equipada", "Internet inclusa", "Pet friendly"],
    condoFeatures: ["Portaria eletrônica", "Elevador", "Lavanderia coletiva"],
    images: gallery(saoVicenteApto),
    broker: brokers[1]!,
  },
  {
    id: "7",
    code: "VP1088",
    slug: "terreno-urbanova-sao-jose-dos-campos-vp1088",
    title: "Terreno plano em condomínio com infraestrutura completa",
    type: "Terreno",
    purpose: "venda",
    city: "São José dos Campos",
    neighborhood: "Urbanova",
    condo: "Condomínio Reserva do Paratehy",
    price: 620000,
    condoFee: 690,
    iptu: 180,
    area: 480,
    landArea: 480,
    bedrooms: 0,
    suites: 0,
    baths: 0,
    parking: 0,
    badge: null,
    featured: false,
    isLaunch: false,
    exclusive: false,
    furnished: false,
    financing: true,
    permuta: true,
    createdAt: "2026-06-14",
    description:
      "Lote plano, com frente para rua interna de baixo fluxo e vizinhança já consolidada. Documentação em dia e aprovação de projeto simplificada junto à administração do condomínio.",
    features: ["Topografia plana", "Documentação regular", "Aceita permuta", "Frente de 15 metros"],
    condoFeatures: ["Portaria 24h", "Ruas asfaltadas", "Área verde preservada", "Ciclovia interna"],
    images: [terrenoUrbanova, regiaoUrbanova],
    broker: brokers[0]!,
  },
  {
    id: "8",
    code: "VP1094",
    slug: "casa-reserva-ruda-sao-jose-dos-campos-vp1094",
    title: "Casa térrea em condomínio, três dormitórios",
    type: "Casa em condomínio",
    purpose: "venda",
    city: "São José dos Campos",
    neighborhood: "Reserva Rudá",
    condo: "Reserva Rudá",
    price: 1150000,
    condoFee: 720,
    iptu: 290,
    area: 168,
    landArea: 300,
    bedrooms: 3,
    suites: 1,
    baths: 3,
    parking: 2,
    badge: null,
    featured: false,
    isLaunch: false,
    exclusive: false,
    furnished: false,
    financing: true,
    permuta: false,
    createdAt: "2026-05-30",
    description:
      "Térrea bem conservada, com quintal aproveitável e garagem coberta para dois carros. Condomínio familiar, com lazer completo e portaria monitorada, próximo a escolas e ao comércio da zona leste.",
    features: ["Quintal", "Garagem coberta", "Churrasqueira", "Armários nos dormitórios"],
    condoFeatures: ["Portaria 24h", "Piscina", "Playground", "Salão de festas", "Espaço fitness"],
    images: gallery(rudaCasa),
    broker: brokers[2]!,
  },
  {
    id: "9",
    code: "VP1101",
    slug: "apartamento-jardim-ismenia-sao-jose-dos-campos-vp1101",
    title: "Apartamento com suíte e varanda, entrega recente",
    type: "Apartamento",
    purpose: "venda",
    city: "São José dos Campos",
    neighborhood: "Jardim Ismênia",
    condo: "Residencial Uberaba",
    price: 465000,
    condoFee: 480,
    iptu: 140,
    area: 68,
    landArea: null,
    bedrooms: 2,
    suites: 1,
    baths: 2,
    parking: 1,
    badge: "Novo",
    featured: false,
    isLaunch: false,
    exclusive: false,
    furnished: false,
    financing: true,
    permuta: false,
    createdAt: "2026-07-12",
    description:
      "Unidade entregue recentemente, com varanda voltada para o miolo do bairro e planta de dois dormitórios com suíte. Região em valorização, com acesso rápido à Avenida Andrômeda e ao eixo da Dutra.",
    features: ["Varanda", "Suíte", "Porcelanato", "Preparação para ar-condicionado"],
    condoFeatures: ["Portaria 24h", "Academia", "Salão de festas", "Playground"],
    images: gallery(ismeniaApto),
    broker: brokers[3]!,
  },
  {
    id: "10",
    code: "VP1110",
    slug: "apartamento-residencial-vitorino-jardim-ismenia-sao-jose-dos-campos-vp1110",
    title: "Residencial Vitorino — dois dormitórios com suíte e rooftop",
    type: "Apartamento",
    purpose: "venda",
    city: "São José dos Campos",
    neighborhood: "Jardim Ismênia",
    condo: "Residencial Vitorino",
    price: 502000,
    condoFee: 520,
    iptu: 150,
    area: 64,
    landArea: null,
    bedrooms: 2,
    suites: 1,
    baths: 2,
    parking: 1,
    badge: "Lançamento",
    featured: true,
    isLaunch: true,
    exclusive: true,
    furnished: false,
    financing: true,
    permuta: false,
    createdAt: "2026-08-01",
    description:
      "Empreendimento contemporâneo na Avenida Uberaba, 370, no Jardim Ismênia. Plantas de dois dormitórios com uma suíte, rooftop com vista para a Serra, spa, espaço gourmet, salão de festas, academia, brinquedoteca e playground. Arquitetura de linhas limpas e áreas comuns entregues equipadas.",
    features: [
      "Dois dormitórios",
      "Uma suíte",
      "Arquitetura contemporânea",
      "Preparação para ar-condicionado",
    ],
    condoFeatures: [
      "Rooftop com vista para a Serra",
      "Spa",
      "Espaço gourmet",
      "Salão de festas",
      "Academia",
      "Brinquedoteca",
      "Playground",
    ],
    images: [vitorino],
    broker: brokers[3]!,
  },
];

export type Launch = {
  slug: string;
  name: string;
  neighborhood: string;
  city: string;
  typologies: string;
  area: string;
  priceFrom: number | null;
  stage: "Lançamento" | "Em obras" | "Pronto para morar";
  image: string;
  images?: string[];
  address?: string;
  highlights: string[];
};

export const launches: Launch[] = [
  {
    slug: "residencial-vitorino",
    name: "Residencial Vitorino",
    neighborhood: "Jardim Ismênia",
    city: "São José dos Campos",
    typologies: "2 dormitórios, 1 suíte",
    area: "a partir de 64 m²",
    priceFrom: 502000,
    stage: "Lançamento",
    image: vitorino,
    images: [vitorino],
    address: "Avenida Uberaba, 370 — Jardim Ismênia, São José dos Campos",
    highlights: [
      "Rooftop com vista para a Serra",
      "Spa",
      "Espaço gourmet",
      "Salão de festas",
      "Academia",
      "Brinquedoteca",
      "Playground",
      "Arquitetura contemporânea",
    ],
  },
];

export type Region = {
  name: string;
  image: string;
};

export const regions: Region[] = [
  { name: "Urbanova", image: regiaoUrbanova },
  { name: "Jardim Aquarius", image: regiaoAquarius },
  { name: "Jardim das Colinas", image: regiaoColinas },
  { name: "Parque Industrial", image: industrialApto },
  { name: "Jardim Satélite", image: rudaCasa },
  { name: "Jardim Ismênia", image: ismeniaApto },
  { name: "Vila Ema", image: regiaoColinas },
  { name: "Jardim do Golfe", image: golfeCasa },
  { name: "Bosque dos Eucaliptos", image: eucaliptosCobertura },
  { name: "Zona Leste", image: saoVicenteApto },
];

export interface Testimonial {
  name: string;
  text: string;
  photo?: string;
  transactionType?: "Compra" | "Venda" | "Locação";
  neighborhood?: string;
}

/**
 * Depoimentos reais de clientes. A seção só é renderizada quando houver
 * pelo menos um item aqui — não inserir depoimentos fictícios.
 */
export const testimonials: Testimonial[] = [];

export const articles = [
  {
    slug: "melhores-bairros-para-morar-em-sao-jose-dos-campos",
    category: "Bairros",
    title: "Melhores bairros para morar em São José dos Campos",
    excerpt:
      "Perfil, infraestrutura e faixa de preço das regiões mais procuradas da cidade, do Urbanova à zona leste.",
    readingTime: "7 min de leitura",
    image: regiaoColinas,
  },
  {
    slug: "como-funciona-o-financiamento-imobiliario",
    category: "Financiamento",
    title: "Como funciona o financiamento imobiliário",
    excerpt:
      "Entrada, prazo, sistemas de amortização e o que os bancos avaliam antes de aprovar a sua carta de crédito.",
    readingTime: "6 min de leitura",
    image: blogFinanciamento,
  },
  {
    slug: "o-que-analisar-antes-de-comprar-um-imovel-na-planta",
    category: "Lançamentos",
    title: "O que analisar antes de comprar um imóvel na planta",
    excerpt:
      "Memorial descritivo, cronograma, correção do saldo devedor e os pontos que costumam passar despercebidos.",
    readingTime: "8 min de leitura",
    image: blogPlanta,
  },
];

export const cities = ["São José dos Campos", "Jacareí", "Caçapava", "Taubaté"];

export const propertyTypes: PropertyType[] = [
  "Casa em condomínio",
  "Casa",
  "Apartamento",
  "Cobertura",
  "Terreno",
];

export const neighborhoods = Array.from(new Set(properties.map((p) => p.neighborhood))).sort(
  (a, b) => a.localeCompare(b, "pt-BR"),
);

export const condos = Array.from(
  new Set(properties.map((p) => p.condo).filter((c): c is string => Boolean(c))),
).sort((a, b) => a.localeCompare(b, "pt-BR"));

export function getProperty(slug: string) {
  return properties.find((p) => p.slug === slug);
}

export function getPropertiesByIds(ids: string[]) {
  return ids
    .map((id) => properties.find((p) => p.id === id))
    .filter((p): p is Property => Boolean(p));
}

export function similarProperties(property: Property, limit = 3) {
  return properties
    .filter((p) => p.id !== property.id)
    .sort((a, b) => {
      const score = (p: Property) =>
        (p.neighborhood === property.neighborhood ? 2 : 0) + (p.type === property.type ? 1 : 0);
      return score(b) - score(a);
    })
    .slice(0, limit);
}
