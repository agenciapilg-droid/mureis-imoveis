export const site = {
  name: "Mureis Imóveis",
  url: "https://mureis-imoveis-preview.agenciapilg.chatgpt.site",
  tagline: "Imobiliária em São José dos Campos e região",
  creci: "CRECI 283.017-F — Pedro Henrique Cardoso",
  phone: "(12) 98264-8633",
  phoneRaw: "5512982648633",
  whatsapp: "5512982648633",
  address: "São José dos Campos/SP",
  /**
   * Indicadores institucionais. Preencher somente com dados reais e
   * verificáveis — a seção fica oculta enquanto a lista estiver vazia.
   */
  stats: [] as { value: string; label: string }[],
};

export const waMessages = {
  general: "Olá! Vim pelo site da Mureis e gostaria de falar com um especialista.",
  evaluation: "Olá! Gostaria de anunciar meu imóvel com a Mureis.",
  launch: (name: string) => `Olá! Gostaria de receber mais informações sobre o ${name}.`,
  property: (code: string, neighborhood?: string) =>
    `Olá! Gostaria de receber mais informações do imóvel código ${code}${neighborhood ? `, localizado no bairro ${neighborhood}` : ""}.`,
  visit: (code: string) =>
    `Olá! Gostaria de agendar uma visita ao imóvel ${code} anunciado no site da Mureis.`,
};

export function whatsappLink(message: string) {
  return `https://wa.me/${site.whatsapp}?text=${encodeURIComponent(message)}`;
}
